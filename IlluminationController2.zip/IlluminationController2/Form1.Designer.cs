﻿namespace IlluminationController2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.switchConfig = new System.Windows.Forms.Button();
            this.updateConfig = new System.Windows.Forms.Button();
            this.uploadConfig = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label101 = new System.Windows.Forms.Label();
            this.comPort = new System.Windows.Forms.TextBox();
            this.portError = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.openConn = new System.Windows.Forms.Button();
            this.closeConn = new System.Windows.Forms.Button();
            this.g5_panel = new System.Windows.Forms.Panel();
            this.label85 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.g5_setting = new System.Windows.Forms.ComboBox();
            this.g4_panel = new System.Windows.Forms.Panel();
            this.label69 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.g4_setting = new System.Windows.Forms.ComboBox();
            this.g3_panel = new System.Windows.Forms.Panel();
            this.label53 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.g3_setting = new System.Windows.Forms.ComboBox();
            this.g2_panel = new System.Windows.Forms.Panel();
            this.label37 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.g2_setting = new System.Windows.Forms.ComboBox();
            this.g1_panel = new System.Windows.Forms.Panel();
            this.label36 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.g1_setting = new System.Windows.Forms.ComboBox();
            this.lightSelect = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.consoleDisplay = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.mainTab = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.c3_panel = new System.Windows.Forms.Panel();
            this.c3_status = new System.Windows.Forms.Button();
            this.c3_error = new System.Windows.Forms.Label();
            this.c3_test = new System.Windows.Forms.Button();
            this.c3_delay = new System.Windows.Forms.TextBox();
            this.c3_pulse = new System.Windows.Forms.TextBox();
            this.c3_strobe = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.c3_intensity = new System.Windows.Forms.TextBox();
            this.c3_edge = new System.Windows.Forms.ComboBox();
            this.c3_mode = new System.Windows.Forms.ComboBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.c3_title = new System.Windows.Forms.Label();
            this.c1_panel = new System.Windows.Forms.Panel();
            this.c1_status = new System.Windows.Forms.Button();
            this.c1_error = new System.Windows.Forms.Label();
            this.c1_test = new System.Windows.Forms.Button();
            this.c1_delay = new System.Windows.Forms.TextBox();
            this.c1_pulse = new System.Windows.Forms.TextBox();
            this.c1_strobe = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.c1_intensity = new System.Windows.Forms.TextBox();
            this.c1_edge = new System.Windows.Forms.ComboBox();
            this.c1_mode = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.c1_title = new System.Windows.Forms.Label();
            this.c2_panel = new System.Windows.Forms.Panel();
            this.c2_status = new System.Windows.Forms.Button();
            this.c2_error = new System.Windows.Forms.Label();
            this.c2_test = new System.Windows.Forms.Button();
            this.c2_delay = new System.Windows.Forms.TextBox();
            this.c2_pulse = new System.Windows.Forms.TextBox();
            this.c2_strobe = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.c2_intensity = new System.Windows.Forms.TextBox();
            this.c2_edge = new System.Windows.Forms.ComboBox();
            this.c2_mode = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.c2_title = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.c6_panel = new System.Windows.Forms.Panel();
            this.c6_status = new System.Windows.Forms.Button();
            this.c6_error = new System.Windows.Forms.Label();
            this.c6_test = new System.Windows.Forms.Button();
            this.c6_delay = new System.Windows.Forms.TextBox();
            this.c6_pulse = new System.Windows.Forms.TextBox();
            this.c6_strobe = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.c6_intensity = new System.Windows.Forms.TextBox();
            this.c6_edge = new System.Windows.Forms.ComboBox();
            this.c6_mode = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.c6_title = new System.Windows.Forms.Label();
            this.c4_panel = new System.Windows.Forms.Panel();
            this.c4_status = new System.Windows.Forms.Button();
            this.c4_error = new System.Windows.Forms.Label();
            this.c4_test = new System.Windows.Forms.Button();
            this.c4_delay = new System.Windows.Forms.TextBox();
            this.c4_pulse = new System.Windows.Forms.TextBox();
            this.c4_strobe = new System.Windows.Forms.ComboBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.c4_intensity = new System.Windows.Forms.TextBox();
            this.c4_edge = new System.Windows.Forms.ComboBox();
            this.c4_mode = new System.Windows.Forms.ComboBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.c4_title = new System.Windows.Forms.Label();
            this.c5_panel = new System.Windows.Forms.Panel();
            this.c5_status = new System.Windows.Forms.Button();
            this.c5_error = new System.Windows.Forms.Label();
            this.c5_test = new System.Windows.Forms.Button();
            this.c5_delay = new System.Windows.Forms.TextBox();
            this.c5_pulse = new System.Windows.Forms.TextBox();
            this.c5_strobe = new System.Windows.Forms.ComboBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.c5_intensity = new System.Windows.Forms.TextBox();
            this.c5_edge = new System.Windows.Forms.ComboBox();
            this.c5_mode = new System.Windows.Forms.ComboBox();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.c5_title = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.c9_panel = new System.Windows.Forms.Panel();
            this.c9_status = new System.Windows.Forms.Button();
            this.c9_error = new System.Windows.Forms.Label();
            this.c9_test = new System.Windows.Forms.Button();
            this.c9_delay = new System.Windows.Forms.TextBox();
            this.c9_pulse = new System.Windows.Forms.TextBox();
            this.c9_strobe = new System.Windows.Forms.ComboBox();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.c9_intensity = new System.Windows.Forms.TextBox();
            this.c9_edge = new System.Windows.Forms.ComboBox();
            this.c9_mode = new System.Windows.Forms.ComboBox();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.c9_title = new System.Windows.Forms.Label();
            this.c7_panel = new System.Windows.Forms.Panel();
            this.c7_status = new System.Windows.Forms.Button();
            this.c7_error = new System.Windows.Forms.Label();
            this.c7_test = new System.Windows.Forms.Button();
            this.c7_delay = new System.Windows.Forms.TextBox();
            this.c7_pulse = new System.Windows.Forms.TextBox();
            this.c7_strobe = new System.Windows.Forms.ComboBox();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.c7_intensity = new System.Windows.Forms.TextBox();
            this.c7_edge = new System.Windows.Forms.ComboBox();
            this.c7_mode = new System.Windows.Forms.ComboBox();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.c7_title = new System.Windows.Forms.Label();
            this.c8_panel = new System.Windows.Forms.Panel();
            this.c8_status = new System.Windows.Forms.Button();
            this.c8_error = new System.Windows.Forms.Label();
            this.c8_test = new System.Windows.Forms.Button();
            this.c8_delay = new System.Windows.Forms.TextBox();
            this.c8_pulse = new System.Windows.Forms.TextBox();
            this.c8_strobe = new System.Windows.Forms.ComboBox();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.c8_intensity = new System.Windows.Forms.TextBox();
            this.c8_edge = new System.Windows.Forms.ComboBox();
            this.c8_mode = new System.Windows.Forms.ComboBox();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.c8_title = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.c12_panel = new System.Windows.Forms.Panel();
            this.c12_status = new System.Windows.Forms.Button();
            this.c12_error = new System.Windows.Forms.Label();
            this.c12_test = new System.Windows.Forms.Button();
            this.c12_delay = new System.Windows.Forms.TextBox();
            this.c12_pulse = new System.Windows.Forms.TextBox();
            this.c12_strobe = new System.Windows.Forms.ComboBox();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.c12_intensity = new System.Windows.Forms.TextBox();
            this.c12_edge = new System.Windows.Forms.ComboBox();
            this.c12_mode = new System.Windows.Forms.ComboBox();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.c12_title = new System.Windows.Forms.Label();
            this.c10_panel = new System.Windows.Forms.Panel();
            this.c10_status = new System.Windows.Forms.Button();
            this.c10_error = new System.Windows.Forms.Label();
            this.c10_test = new System.Windows.Forms.Button();
            this.c10_delay = new System.Windows.Forms.TextBox();
            this.c10_pulse = new System.Windows.Forms.TextBox();
            this.c10_strobe = new System.Windows.Forms.ComboBox();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.c10_intensity = new System.Windows.Forms.TextBox();
            this.c10_edge = new System.Windows.Forms.ComboBox();
            this.c10_mode = new System.Windows.Forms.ComboBox();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.c10_title = new System.Windows.Forms.Label();
            this.c11_panel = new System.Windows.Forms.Panel();
            this.c11_status = new System.Windows.Forms.Button();
            this.c11_error = new System.Windows.Forms.Label();
            this.c11_test = new System.Windows.Forms.Button();
            this.c11_delay = new System.Windows.Forms.TextBox();
            this.c11_pulse = new System.Windows.Forms.TextBox();
            this.c11_strobe = new System.Windows.Forms.ComboBox();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.c11_intensity = new System.Windows.Forms.TextBox();
            this.c11_edge = new System.Windows.Forms.ComboBox();
            this.c11_mode = new System.Windows.Forms.ComboBox();
            this.label97 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.c11_title = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.c15_panel = new System.Windows.Forms.Panel();
            this.c15_status = new System.Windows.Forms.Button();
            this.c15_error = new System.Windows.Forms.Label();
            this.c15_test = new System.Windows.Forms.Button();
            this.c15_delay = new System.Windows.Forms.TextBox();
            this.c15_pulse = new System.Windows.Forms.TextBox();
            this.c15_strobe = new System.Windows.Forms.ComboBox();
            this.label102 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.c15_intensity = new System.Windows.Forms.TextBox();
            this.c15_edge = new System.Windows.Forms.ComboBox();
            this.c15_mode = new System.Windows.Forms.ComboBox();
            this.label105 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.c15_title = new System.Windows.Forms.Label();
            this.c13_panel = new System.Windows.Forms.Panel();
            this.c13_status = new System.Windows.Forms.Button();
            this.c13_error = new System.Windows.Forms.Label();
            this.c13_test = new System.Windows.Forms.Button();
            this.c13_delay = new System.Windows.Forms.TextBox();
            this.c13_pulse = new System.Windows.Forms.TextBox();
            this.c13_strobe = new System.Windows.Forms.ComboBox();
            this.label110 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.c13_intensity = new System.Windows.Forms.TextBox();
            this.c13_edge = new System.Windows.Forms.ComboBox();
            this.c13_mode = new System.Windows.Forms.ComboBox();
            this.label113 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.label115 = new System.Windows.Forms.Label();
            this.c13_title = new System.Windows.Forms.Label();
            this.c14_panel = new System.Windows.Forms.Panel();
            this.c14_status = new System.Windows.Forms.Button();
            this.c14_error = new System.Windows.Forms.Label();
            this.c14_test = new System.Windows.Forms.Button();
            this.c14_delay = new System.Windows.Forms.TextBox();
            this.c14_pulse = new System.Windows.Forms.TextBox();
            this.c14_strobe = new System.Windows.Forms.ComboBox();
            this.label118 = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.c14_intensity = new System.Windows.Forms.TextBox();
            this.c14_edge = new System.Windows.Forms.ComboBox();
            this.c14_mode = new System.Windows.Forms.ComboBox();
            this.label121 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.c14_title = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.panel6 = new System.Windows.Forms.Panel();
            this.c16_error = new System.Windows.Forms.Label();
            this.c16_status = new System.Windows.Forms.Button();
            this.label126 = new System.Windows.Forms.Label();
            this.c16_test = new System.Windows.Forms.Button();
            this.c16_delay = new System.Windows.Forms.TextBox();
            this.c16_pulse = new System.Windows.Forms.TextBox();
            this.c16_strobe = new System.Windows.Forms.ComboBox();
            this.label127 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.c16_intensity = new System.Windows.Forms.TextBox();
            this.c16_edge = new System.Windows.Forms.ComboBox();
            this.c16_mode = new System.Windows.Forms.ComboBox();
            this.label130 = new System.Windows.Forms.Label();
            this.label131 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.label133 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.testUpdatedComms = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel5.SuspendLayout();
            this.g5_panel.SuspendLayout();
            this.g4_panel.SuspendLayout();
            this.g3_panel.SuspendLayout();
            this.g2_panel.SuspendLayout();
            this.g1_panel.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.mainTab.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.c3_panel.SuspendLayout();
            this.c1_panel.SuspendLayout();
            this.c2_panel.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.c6_panel.SuspendLayout();
            this.c4_panel.SuspendLayout();
            this.c5_panel.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.c9_panel.SuspendLayout();
            this.c7_panel.SuspendLayout();
            this.c8_panel.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.c12_panel.SuspendLayout();
            this.c10_panel.SuspendLayout();
            this.c11_panel.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.c15_panel.SuspendLayout();
            this.c13_panel.SuspendLayout();
            this.c14_panel.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.testUpdatedComms);
            this.panel1.Controls.Add(this.switchConfig);
            this.panel1.Controls.Add(this.updateConfig);
            this.panel1.Controls.Add(this.uploadConfig);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(179, 828);
            this.panel1.TabIndex = 0;
            // 
            // switchConfig
            // 
            this.switchConfig.Location = new System.Drawing.Point(7, 31);
            this.switchConfig.Name = "switchConfig";
            this.switchConfig.Size = new System.Drawing.Size(144, 29);
            this.switchConfig.TabIndex = 4;
            this.switchConfig.Text = "Switch Config";
            this.switchConfig.UseVisualStyleBackColor = true;
            this.switchConfig.Click += new System.EventHandler(this.switchConfig_Click);
            // 
            // updateConfig
            // 
            this.updateConfig.Location = new System.Drawing.Point(7, 76);
            this.updateConfig.Name = "updateConfig";
            this.updateConfig.Size = new System.Drawing.Size(144, 29);
            this.updateConfig.TabIndex = 2;
            this.updateConfig.Text = "Update Config";
            this.updateConfig.UseVisualStyleBackColor = true;
            this.updateConfig.Click += new System.EventHandler(this.updateConfig_Click);
            // 
            // uploadConfig
            // 
            this.uploadConfig.Enabled = false;
            this.uploadConfig.Location = new System.Drawing.Point(7, 121);
            this.uploadConfig.Name = "uploadConfig";
            this.uploadConfig.Size = new System.Drawing.Size(144, 29);
            this.uploadConfig.TabIndex = 1;
            this.uploadConfig.Text = "Upload Config";
            this.uploadConfig.UseVisualStyleBackColor = true;
            this.uploadConfig.Click += new System.EventHandler(this.uploadConfig_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Main Controls";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label101);
            this.panel2.Controls.Add(this.comPort);
            this.panel2.Controls.Add(this.portError);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.openConn);
            this.panel2.Controls.Add(this.closeConn);
            this.panel2.Controls.Add(this.g5_panel);
            this.panel2.Controls.Add(this.g4_panel);
            this.panel2.Controls.Add(this.g3_panel);
            this.panel2.Controls.Add(this.g2_panel);
            this.panel2.Controls.Add(this.g1_panel);
            this.panel2.Controls.Add(this.lightSelect);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(179, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(197, 828);
            this.panel2.TabIndex = 1;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(0, 154);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(47, 13);
            this.label101.TabIndex = 32;
            this.label101.Text = "label101";
            this.label101.Visible = false;
            // 
            // comPort
            // 
            this.comPort.Enabled = false;
            this.comPort.Location = new System.Drawing.Point(4, 52);
            this.comPort.Name = "comPort";
            this.comPort.Size = new System.Drawing.Size(80, 20);
            this.comPort.TabIndex = 31;
            // 
            // portError
            // 
            this.portError.AutoSize = true;
            this.portError.Location = new System.Drawing.Point(4, 155);
            this.portError.Name = "portError";
            this.portError.Size = new System.Drawing.Size(0, 13);
            this.portError.TabIndex = 30;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.label20);
            this.panel5.Controls.Add(this.label109);
            this.panel5.Location = new System.Drawing.Point(4, 741);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(177, 27);
            this.panel5.TabIndex = 28;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft PhagsPa", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(3, 3);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(56, 17);
            this.label20.TabIndex = 23;
            this.label20.Text = "Group 6";
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label109.Location = new System.Drawing.Point(95, 3);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(76, 18);
            this.label109.TabIndex = 17;
            this.label109.Text = "Channel 16";
            // 
            // openConn
            // 
            this.openConn.Enabled = false;
            this.openConn.Location = new System.Drawing.Point(3, 84);
            this.openConn.Name = "openConn";
            this.openConn.Size = new System.Drawing.Size(188, 29);
            this.openConn.TabIndex = 29;
            this.openConn.Text = "Open port connection";
            this.openConn.UseVisualStyleBackColor = true;
            this.openConn.Click += new System.EventHandler(this.openConn_Click);
            // 
            // closeConn
            // 
            this.closeConn.Location = new System.Drawing.Point(3, 123);
            this.closeConn.Name = "closeConn";
            this.closeConn.Size = new System.Drawing.Size(188, 29);
            this.closeConn.TabIndex = 28;
            this.closeConn.Text = "Close port connection";
            this.closeConn.UseVisualStyleBackColor = true;
            this.closeConn.Click += new System.EventHandler(this.closeConn_Click);
            // 
            // g5_panel
            // 
            this.g5_panel.Controls.Add(this.label85);
            this.g5_panel.Controls.Add(this.label92);
            this.g5_panel.Controls.Add(this.label93);
            this.g5_panel.Controls.Add(this.label100);
            this.g5_panel.Controls.Add(this.g5_setting);
            this.g5_panel.Location = new System.Drawing.Point(4, 637);
            this.g5_panel.Name = "g5_panel";
            this.g5_panel.Size = new System.Drawing.Size(177, 98);
            this.g5_panel.TabIndex = 27;
            this.g5_panel.Paint += new System.Windows.Forms.PaintEventHandler(this.g5_panel_Paint);
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("Microsoft PhagsPa", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label85.Location = new System.Drawing.Point(3, 3);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(56, 17);
            this.label85.TabIndex = 23;
            this.label85.Text = "Group 5";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label92.Location = new System.Drawing.Point(95, 70);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(76, 18);
            this.label92.TabIndex = 23;
            this.label92.Text = "Channel 15";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label93.Location = new System.Drawing.Point(95, 36);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(76, 18);
            this.label93.TabIndex = 22;
            this.label93.Text = "Channel 14";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label100.Location = new System.Drawing.Point(95, 3);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(76, 18);
            this.label100.TabIndex = 17;
            this.label100.Text = "Channel 13";
            // 
            // g5_setting
            // 
            this.g5_setting.FormattingEnabled = true;
            this.g5_setting.Items.AddRange(new object[] {
            "Ungrouped",
            "Grouped"});
            this.g5_setting.Location = new System.Drawing.Point(3, 24);
            this.g5_setting.Name = "g5_setting";
            this.g5_setting.Size = new System.Drawing.Size(77, 21);
            this.g5_setting.TabIndex = 21;
            this.g5_setting.Text = "Ungrouped";
            this.g5_setting.SelectedIndexChanged += new System.EventHandler(this.g5_setting_SelectedIndexChanged);
            // 
            // g4_panel
            // 
            this.g4_panel.Controls.Add(this.label69);
            this.g4_panel.Controls.Add(this.label76);
            this.g4_panel.Controls.Add(this.label77);
            this.g4_panel.Controls.Add(this.label84);
            this.g4_panel.Controls.Add(this.g4_setting);
            this.g4_panel.Location = new System.Drawing.Point(4, 532);
            this.g4_panel.Name = "g4_panel";
            this.g4_panel.Size = new System.Drawing.Size(177, 98);
            this.g4_panel.TabIndex = 27;
            this.g4_panel.Paint += new System.Windows.Forms.PaintEventHandler(this.g4_panel_Paint);
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Microsoft PhagsPa", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.Location = new System.Drawing.Point(3, 3);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(56, 17);
            this.label69.TabIndex = 23;
            this.label69.Text = "Group 4";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.Location = new System.Drawing.Point(95, 70);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(76, 18);
            this.label76.TabIndex = 23;
            this.label76.Text = "Channel 12";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label77.Location = new System.Drawing.Point(95, 36);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(76, 18);
            this.label77.TabIndex = 22;
            this.label77.Text = "Channel 11";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label84.Location = new System.Drawing.Point(95, 3);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(76, 18);
            this.label84.TabIndex = 17;
            this.label84.Text = "Channel 10";
            // 
            // g4_setting
            // 
            this.g4_setting.FormattingEnabled = true;
            this.g4_setting.Items.AddRange(new object[] {
            "Ungrouped",
            "Grouped"});
            this.g4_setting.Location = new System.Drawing.Point(3, 24);
            this.g4_setting.Name = "g4_setting";
            this.g4_setting.Size = new System.Drawing.Size(77, 21);
            this.g4_setting.TabIndex = 21;
            this.g4_setting.Text = "Ungrouped";
            this.g4_setting.SelectedIndexChanged += new System.EventHandler(this.g4_setting_SelectedIndexChanged);
            // 
            // g3_panel
            // 
            this.g3_panel.Controls.Add(this.label53);
            this.g3_panel.Controls.Add(this.label60);
            this.g3_panel.Controls.Add(this.label61);
            this.g3_panel.Controls.Add(this.label68);
            this.g3_panel.Controls.Add(this.g3_setting);
            this.g3_panel.Location = new System.Drawing.Point(4, 429);
            this.g3_panel.Name = "g3_panel";
            this.g3_panel.Size = new System.Drawing.Size(177, 98);
            this.g3_panel.TabIndex = 27;
            this.g3_panel.Paint += new System.Windows.Forms.PaintEventHandler(this.g3_panel_Paint);
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Microsoft PhagsPa", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(3, 3);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(56, 17);
            this.label53.TabIndex = 23;
            this.label53.Text = "Group 3";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(95, 70);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(69, 18);
            this.label60.TabIndex = 23;
            this.label60.Text = "Channel 9";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(95, 36);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(69, 18);
            this.label61.TabIndex = 22;
            this.label61.Text = "Channel 8";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.Location = new System.Drawing.Point(95, 3);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(69, 18);
            this.label68.TabIndex = 17;
            this.label68.Text = "Channel 7";
            // 
            // g3_setting
            // 
            this.g3_setting.FormattingEnabled = true;
            this.g3_setting.Items.AddRange(new object[] {
            "Ungrouped",
            "Grouped"});
            this.g3_setting.Location = new System.Drawing.Point(3, 24);
            this.g3_setting.Name = "g3_setting";
            this.g3_setting.Size = new System.Drawing.Size(77, 21);
            this.g3_setting.TabIndex = 21;
            this.g3_setting.Text = "Ungrouped";
            this.g3_setting.SelectedIndexChanged += new System.EventHandler(this.g3_setting_SelectedIndexChanged);
            // 
            // g2_panel
            // 
            this.g2_panel.Controls.Add(this.label37);
            this.g2_panel.Controls.Add(this.label44);
            this.g2_panel.Controls.Add(this.label45);
            this.g2_panel.Controls.Add(this.label52);
            this.g2_panel.Controls.Add(this.g2_setting);
            this.g2_panel.Location = new System.Drawing.Point(4, 326);
            this.g2_panel.Name = "g2_panel";
            this.g2_panel.Size = new System.Drawing.Size(177, 98);
            this.g2_panel.TabIndex = 27;
            this.g2_panel.Paint += new System.Windows.Forms.PaintEventHandler(this.g2_panel_Paint);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft PhagsPa", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(3, 3);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(56, 17);
            this.label37.TabIndex = 23;
            this.label37.Text = "Group 2";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(95, 70);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(69, 18);
            this.label44.TabIndex = 23;
            this.label44.Text = "Channel 6";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(95, 36);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(69, 18);
            this.label45.TabIndex = 22;
            this.label45.Text = "Channel 5";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(95, 3);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(69, 18);
            this.label52.TabIndex = 17;
            this.label52.Text = "Channel 4";
            // 
            // g2_setting
            // 
            this.g2_setting.FormattingEnabled = true;
            this.g2_setting.Items.AddRange(new object[] {
            "Ungrouped",
            "Grouped"});
            this.g2_setting.Location = new System.Drawing.Point(3, 24);
            this.g2_setting.Name = "g2_setting";
            this.g2_setting.Size = new System.Drawing.Size(77, 21);
            this.g2_setting.TabIndex = 21;
            this.g2_setting.Text = "Ungrouped";
            this.g2_setting.SelectedIndexChanged += new System.EventHandler(this.g2_setting_SelectedIndexChanged);
            // 
            // g1_panel
            // 
            this.g1_panel.Controls.Add(this.label36);
            this.g1_panel.Controls.Add(this.label29);
            this.g1_panel.Controls.Add(this.label28);
            this.g1_panel.Controls.Add(this.label21);
            this.g1_panel.Controls.Add(this.g1_setting);
            this.g1_panel.Location = new System.Drawing.Point(4, 224);
            this.g1_panel.Name = "g1_panel";
            this.g1_panel.Size = new System.Drawing.Size(177, 98);
            this.g1_panel.TabIndex = 22;
            this.g1_panel.Paint += new System.Windows.Forms.PaintEventHandler(this.g1_panel_Paint);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft PhagsPa", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(3, 3);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(56, 17);
            this.label36.TabIndex = 23;
            this.label36.Text = "Group 1";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(95, 70);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(69, 18);
            this.label29.TabIndex = 23;
            this.label29.Text = "Channel 3";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(95, 36);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(69, 18);
            this.label28.TabIndex = 22;
            this.label28.Text = "Channel 2";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(95, 3);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(69, 18);
            this.label21.TabIndex = 17;
            this.label21.Text = "Channel 1";
            // 
            // g1_setting
            // 
            this.g1_setting.FormattingEnabled = true;
            this.g1_setting.Items.AddRange(new object[] {
            "Ungrouped",
            "Grouped"});
            this.g1_setting.Location = new System.Drawing.Point(3, 24);
            this.g1_setting.Name = "g1_setting";
            this.g1_setting.Size = new System.Drawing.Size(77, 21);
            this.g1_setting.TabIndex = 21;
            this.g1_setting.Text = "Ungrouped";
            this.g1_setting.SelectedIndexChanged += new System.EventHandler(this.g1_setting_SelectedIndexChanged);
            // 
            // lightSelect
            // 
            this.lightSelect.FormattingEnabled = true;
            this.lightSelect.Items.AddRange(new object[] {
            "Board 1",
            "Board 2",
            "Board 3",
            "Board 4",
            "Board 5",
            "Board 6",
            "Board 7",
            "Board 8"});
            this.lightSelect.Location = new System.Drawing.Point(104, 52);
            this.lightSelect.Name = "lightSelect";
            this.lightSelect.Size = new System.Drawing.Size(77, 21);
            this.lightSelect.TabIndex = 20;
            this.lightSelect.SelectedIndexChanged += new System.EventHandler(this.lightSelect_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(1, 201);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(102, 15);
            this.label13.TabIndex = 19;
            this.label13.Text = "Channel Selection";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(101, 30);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(90, 15);
            this.label12.TabIndex = 18;
            this.label12.Text = "Board Selection";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(3, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 15);
            this.label5.TabIndex = 2;
            this.label5.Text = "COM Port";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "Board Settings";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.consoleDisplay);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(376, 645);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(622, 183);
            this.panel3.TabIndex = 2;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // consoleDisplay
            // 
            this.consoleDisplay.FormattingEnabled = true;
            this.consoleDisplay.Location = new System.Drawing.Point(7, 25);
            this.consoleDisplay.Name = "consoleDisplay";
            this.consoleDisplay.Size = new System.Drawing.Size(615, 147);
            this.consoleDisplay.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 19);
            this.label4.TabIndex = 2;
            this.label4.Text = "Console";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.mainTab);
            this.panel4.Controls.Add(this.button2);
            this.panel4.Controls.Add(this.button1);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(376, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(622, 645);
            this.panel4.TabIndex = 3;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // mainTab
            // 
            this.mainTab.Controls.Add(this.tabPage1);
            this.mainTab.Controls.Add(this.tabPage2);
            this.mainTab.Controls.Add(this.tabPage3);
            this.mainTab.Controls.Add(this.tabPage4);
            this.mainTab.Controls.Add(this.tabPage5);
            this.mainTab.Controls.Add(this.tabPage6);
            this.mainTab.Location = new System.Drawing.Point(7, 38);
            this.mainTab.Name = "mainTab";
            this.mainTab.SelectedIndex = 0;
            this.mainTab.Size = new System.Drawing.Size(619, 596);
            this.mainTab.TabIndex = 5;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.c3_panel);
            this.tabPage1.Controls.Add(this.c1_panel);
            this.tabPage1.Controls.Add(this.c2_panel);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(611, 570);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "G1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // c3_panel
            // 
            this.c3_panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c3_panel.Controls.Add(this.c3_status);
            this.c3_panel.Controls.Add(this.c3_error);
            this.c3_panel.Controls.Add(this.c3_test);
            this.c3_panel.Controls.Add(this.c3_delay);
            this.c3_panel.Controls.Add(this.c3_pulse);
            this.c3_panel.Controls.Add(this.c3_strobe);
            this.c3_panel.Controls.Add(this.label30);
            this.c3_panel.Controls.Add(this.label31);
            this.c3_panel.Controls.Add(this.label32);
            this.c3_panel.Controls.Add(this.c3_intensity);
            this.c3_panel.Controls.Add(this.c3_edge);
            this.c3_panel.Controls.Add(this.c3_mode);
            this.c3_panel.Controls.Add(this.label33);
            this.c3_panel.Controls.Add(this.label34);
            this.c3_panel.Controls.Add(this.label35);
            this.c3_panel.Controls.Add(this.c3_title);
            this.c3_panel.Location = new System.Drawing.Point(0, 382);
            this.c3_panel.Name = "c3_panel";
            this.c3_panel.Size = new System.Drawing.Size(607, 182);
            this.c3_panel.TabIndex = 18;
            // 
            // c3_status
            // 
            this.c3_status.BackColor = System.Drawing.Color.Blue;
            this.c3_status.Enabled = false;
            this.c3_status.Location = new System.Drawing.Point(464, 29);
            this.c3_status.Name = "c3_status";
            this.c3_status.Size = new System.Drawing.Size(108, 83);
            this.c3_status.TabIndex = 16;
            this.c3_status.UseVisualStyleBackColor = false;
            this.c3_status.Click += new System.EventHandler(this.c3_status_Click);
            // 
            // c3_error
            // 
            this.c3_error.AutoSize = true;
            this.c3_error.ForeColor = System.Drawing.Color.White;
            this.c3_error.Location = new System.Drawing.Point(3, 157);
            this.c3_error.Name = "c3_error";
            this.c3_error.Size = new System.Drawing.Size(32, 13);
            this.c3_error.TabIndex = 15;
            this.c3_error.Text = "Error:";
            this.c3_error.Click += new System.EventHandler(this.c3_error_Click);
            // 
            // c3_test
            // 
            this.c3_test.Enabled = false;
            this.c3_test.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c3_test.Location = new System.Drawing.Point(464, 112);
            this.c3_test.Name = "c3_test";
            this.c3_test.Size = new System.Drawing.Size(108, 28);
            this.c3_test.TabIndex = 6;
            this.c3_test.Text = "Test";
            this.c3_test.UseVisualStyleBackColor = true;
            this.c3_test.Click += new System.EventHandler(this.c3_test_Click);
            // 
            // c3_delay
            // 
            this.c3_delay.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c3_delay.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c3_delay.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c3_delay.Enabled = false;
            this.c3_delay.Location = new System.Drawing.Point(274, 120);
            this.c3_delay.Name = "c3_delay";
            this.c3_delay.Size = new System.Drawing.Size(69, 20);
            this.c3_delay.TabIndex = 14;
            this.c3_delay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c3_delay.TextChanged += new System.EventHandler(this.c3_delay_TextChanged);
            // 
            // c3_pulse
            // 
            this.c3_pulse.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c3_pulse.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c3_pulse.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c3_pulse.Enabled = false;
            this.c3_pulse.Location = new System.Drawing.Point(274, 75);
            this.c3_pulse.Name = "c3_pulse";
            this.c3_pulse.Size = new System.Drawing.Size(69, 20);
            this.c3_pulse.TabIndex = 13;
            this.c3_pulse.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c3_pulse.TextChanged += new System.EventHandler(this.c3_pulse_TextChanged);
            // 
            // c3_strobe
            // 
            this.c3_strobe.Enabled = false;
            this.c3_strobe.FormattingEnabled = true;
            this.c3_strobe.Items.AddRange(new object[] {
            "None",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.c3_strobe.Location = new System.Drawing.Point(274, 29);
            this.c3_strobe.Name = "c3_strobe";
            this.c3_strobe.Size = new System.Drawing.Size(69, 21);
            this.c3_strobe.TabIndex = 12;
            this.c3_strobe.Text = "None";
            this.c3_strobe.SelectedIndexChanged += new System.EventHandler(this.c3_strobe_SelectedIndexChanged);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(215, 120);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(44, 18);
            this.label30.TabIndex = 11;
            this.label30.Text = "Delay";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(215, 75);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(41, 18);
            this.label31.TabIndex = 10;
            this.label31.Text = "Pulse";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(215, 29);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(48, 18);
            this.label32.TabIndex = 9;
            this.label32.Text = "Strobe";
            // 
            // c3_intensity
            // 
            this.c3_intensity.AutoCompleteCustomSource.AddRange(new string[] {
            "4096"});
            this.c3_intensity.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c3_intensity.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c3_intensity.Location = new System.Drawing.Point(75, 29);
            this.c3_intensity.Name = "c3_intensity";
            this.c3_intensity.Size = new System.Drawing.Size(69, 20);
            this.c3_intensity.TabIndex = 8;
            this.c3_intensity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c3_intensity.TextChanged += new System.EventHandler(this.c3_intensity_TextChanged);
            // 
            // c3_edge
            // 
            this.c3_edge.Enabled = false;
            this.c3_edge.FormattingEnabled = true;
            this.c3_edge.Items.AddRange(new object[] {
            "Rising",
            "Falling"});
            this.c3_edge.Location = new System.Drawing.Point(75, 72);
            this.c3_edge.Name = "c3_edge";
            this.c3_edge.Size = new System.Drawing.Size(69, 21);
            this.c3_edge.TabIndex = 7;
            this.c3_edge.Text = "Rising";
            this.c3_edge.SelectedIndexChanged += new System.EventHandler(this.c3_edge_SelectedIndexChanged);
            // 
            // c3_mode
            // 
            this.c3_mode.FormattingEnabled = true;
            this.c3_mode.Items.AddRange(new object[] {
            "Strobe",
            "Static"});
            this.c3_mode.Location = new System.Drawing.Point(75, 120);
            this.c3_mode.Name = "c3_mode";
            this.c3_mode.Size = new System.Drawing.Size(69, 21);
            this.c3_mode.TabIndex = 6;
            this.c3_mode.Text = "Static";
            this.c3_mode.SelectedIndexChanged += new System.EventHandler(this.c3_mode_SelectedIndexChanged);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(3, 120);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(44, 18);
            this.label33.TabIndex = 3;
            this.label33.Text = "Mode";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(3, 75);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(39, 18);
            this.label34.TabIndex = 2;
            this.label34.Text = "Edge";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(3, 29);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(61, 18);
            this.label35.TabIndex = 1;
            this.label35.Text = "Intensity";
            // 
            // c3_title
            // 
            this.c3_title.AutoSize = true;
            this.c3_title.Location = new System.Drawing.Point(3, 3);
            this.c3_title.Name = "c3_title";
            this.c3_title.Size = new System.Drawing.Size(85, 13);
            this.c3_title.TabIndex = 0;
            this.c3_title.Text = "Channel 3 [Blue]";
            this.c3_title.Click += new System.EventHandler(this.c3_title_Click);
            // 
            // c1_panel
            // 
            this.c1_panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c1_panel.Controls.Add(this.c1_status);
            this.c1_panel.Controls.Add(this.c1_error);
            this.c1_panel.Controls.Add(this.c1_test);
            this.c1_panel.Controls.Add(this.c1_delay);
            this.c1_panel.Controls.Add(this.c1_pulse);
            this.c1_panel.Controls.Add(this.c1_strobe);
            this.c1_panel.Controls.Add(this.label11);
            this.c1_panel.Controls.Add(this.label10);
            this.c1_panel.Controls.Add(this.label9);
            this.c1_panel.Controls.Add(this.c1_intensity);
            this.c1_panel.Controls.Add(this.c1_edge);
            this.c1_panel.Controls.Add(this.c1_mode);
            this.c1_panel.Controls.Add(this.label8);
            this.c1_panel.Controls.Add(this.label7);
            this.c1_panel.Controls.Add(this.label6);
            this.c1_panel.Controls.Add(this.c1_title);
            this.c1_panel.Location = new System.Drawing.Point(0, 6);
            this.c1_panel.Name = "c1_panel";
            this.c1_panel.Size = new System.Drawing.Size(607, 182);
            this.c1_panel.TabIndex = 5;
            // 
            // c1_status
            // 
            this.c1_status.BackColor = System.Drawing.Color.Red;
            this.c1_status.Enabled = false;
            this.c1_status.Location = new System.Drawing.Point(464, 29);
            this.c1_status.Name = "c1_status";
            this.c1_status.Size = new System.Drawing.Size(108, 83);
            this.c1_status.TabIndex = 16;
            this.c1_status.UseVisualStyleBackColor = false;
            this.c1_status.Click += new System.EventHandler(this.c1_status_Click);
            // 
            // c1_error
            // 
            this.c1_error.AutoSize = true;
            this.c1_error.ForeColor = System.Drawing.Color.White;
            this.c1_error.Location = new System.Drawing.Point(3, 157);
            this.c1_error.Name = "c1_error";
            this.c1_error.Size = new System.Drawing.Size(32, 13);
            this.c1_error.TabIndex = 15;
            this.c1_error.Text = "Error:";
            this.c1_error.Click += new System.EventHandler(this.c1_error_Click);
            // 
            // c1_test
            // 
            this.c1_test.Enabled = false;
            this.c1_test.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c1_test.Location = new System.Drawing.Point(464, 112);
            this.c1_test.Name = "c1_test";
            this.c1_test.Size = new System.Drawing.Size(108, 28);
            this.c1_test.TabIndex = 6;
            this.c1_test.Text = "Test";
            this.c1_test.UseVisualStyleBackColor = true;
            this.c1_test.Click += new System.EventHandler(this.c1_test_Click);
            // 
            // c1_delay
            // 
            this.c1_delay.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c1_delay.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c1_delay.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c1_delay.Enabled = false;
            this.c1_delay.Location = new System.Drawing.Point(274, 120);
            this.c1_delay.Name = "c1_delay";
            this.c1_delay.Size = new System.Drawing.Size(69, 20);
            this.c1_delay.TabIndex = 14;
            this.c1_delay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c1_delay.TextChanged += new System.EventHandler(this.c1_delay_TextChanged);
            // 
            // c1_pulse
            // 
            this.c1_pulse.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c1_pulse.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c1_pulse.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c1_pulse.Enabled = false;
            this.c1_pulse.Location = new System.Drawing.Point(274, 75);
            this.c1_pulse.Name = "c1_pulse";
            this.c1_pulse.Size = new System.Drawing.Size(69, 20);
            this.c1_pulse.TabIndex = 13;
            this.c1_pulse.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c1_pulse.TextChanged += new System.EventHandler(this.c1_pulse_TextChanged);
            // 
            // c1_strobe
            // 
            this.c1_strobe.Enabled = false;
            this.c1_strobe.FormattingEnabled = true;
            this.c1_strobe.Items.AddRange(new object[] {
            "None",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.c1_strobe.Location = new System.Drawing.Point(274, 29);
            this.c1_strobe.Name = "c1_strobe";
            this.c1_strobe.Size = new System.Drawing.Size(69, 21);
            this.c1_strobe.TabIndex = 12;
            this.c1_strobe.Text = "None";
            this.c1_strobe.SelectedIndexChanged += new System.EventHandler(this.c1_strobe_SelectedIndexChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(215, 120);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(44, 18);
            this.label11.TabIndex = 11;
            this.label11.Text = "Delay";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(215, 75);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 18);
            this.label10.TabIndex = 10;
            this.label10.Text = "Pulse";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(215, 29);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 18);
            this.label9.TabIndex = 9;
            this.label9.Text = "Strobe";
            // 
            // c1_intensity
            // 
            this.c1_intensity.AutoCompleteCustomSource.AddRange(new string[] {
            "4096"});
            this.c1_intensity.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c1_intensity.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c1_intensity.Location = new System.Drawing.Point(75, 29);
            this.c1_intensity.Name = "c1_intensity";
            this.c1_intensity.Size = new System.Drawing.Size(69, 20);
            this.c1_intensity.TabIndex = 8;
            this.c1_intensity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c1_intensity.TextChanged += new System.EventHandler(this.c1_intensity_TextChanged);
            // 
            // c1_edge
            // 
            this.c1_edge.Enabled = false;
            this.c1_edge.FormattingEnabled = true;
            this.c1_edge.Items.AddRange(new object[] {
            "Rising",
            "Falling"});
            this.c1_edge.Location = new System.Drawing.Point(75, 72);
            this.c1_edge.Name = "c1_edge";
            this.c1_edge.Size = new System.Drawing.Size(69, 21);
            this.c1_edge.TabIndex = 7;
            this.c1_edge.Text = "Rising";
            this.c1_edge.SelectedIndexChanged += new System.EventHandler(this.c1_edge_SelectedIndexChanged);
            // 
            // c1_mode
            // 
            this.c1_mode.FormattingEnabled = true;
            this.c1_mode.Items.AddRange(new object[] {
            "Strobe",
            "Static"});
            this.c1_mode.Location = new System.Drawing.Point(75, 120);
            this.c1_mode.Name = "c1_mode";
            this.c1_mode.Size = new System.Drawing.Size(69, 21);
            this.c1_mode.TabIndex = 6;
            this.c1_mode.Text = "Static";
            this.c1_mode.SelectedIndexChanged += new System.EventHandler(this.c1_mode_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(3, 120);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 18);
            this.label8.TabIndex = 3;
            this.label8.Text = "Mode";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(3, 75);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(39, 18);
            this.label7.TabIndex = 2;
            this.label7.Text = "Edge";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(3, 29);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 18);
            this.label6.TabIndex = 1;
            this.label6.Text = "Intensity";
            // 
            // c1_title
            // 
            this.c1_title.AutoSize = true;
            this.c1_title.Location = new System.Drawing.Point(3, 3);
            this.c1_title.Name = "c1_title";
            this.c1_title.Size = new System.Drawing.Size(84, 13);
            this.c1_title.TabIndex = 0;
            this.c1_title.Text = "Channel 1 [Red]";
            this.c1_title.Click += new System.EventHandler(this.c1_title_Click);
            // 
            // c2_panel
            // 
            this.c2_panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c2_panel.Controls.Add(this.c2_status);
            this.c2_panel.Controls.Add(this.c2_error);
            this.c2_panel.Controls.Add(this.c2_test);
            this.c2_panel.Controls.Add(this.c2_delay);
            this.c2_panel.Controls.Add(this.c2_pulse);
            this.c2_panel.Controls.Add(this.c2_strobe);
            this.c2_panel.Controls.Add(this.label22);
            this.c2_panel.Controls.Add(this.label23);
            this.c2_panel.Controls.Add(this.label24);
            this.c2_panel.Controls.Add(this.c2_intensity);
            this.c2_panel.Controls.Add(this.c2_edge);
            this.c2_panel.Controls.Add(this.c2_mode);
            this.c2_panel.Controls.Add(this.label25);
            this.c2_panel.Controls.Add(this.label26);
            this.c2_panel.Controls.Add(this.label27);
            this.c2_panel.Controls.Add(this.c2_title);
            this.c2_panel.Location = new System.Drawing.Point(0, 194);
            this.c2_panel.Name = "c2_panel";
            this.c2_panel.Size = new System.Drawing.Size(607, 182);
            this.c2_panel.TabIndex = 17;
            // 
            // c2_status
            // 
            this.c2_status.BackColor = System.Drawing.Color.Lime;
            this.c2_status.Enabled = false;
            this.c2_status.Location = new System.Drawing.Point(464, 29);
            this.c2_status.Name = "c2_status";
            this.c2_status.Size = new System.Drawing.Size(108, 83);
            this.c2_status.TabIndex = 16;
            this.c2_status.UseVisualStyleBackColor = false;
            this.c2_status.Click += new System.EventHandler(this.c2_status_Click);
            // 
            // c2_error
            // 
            this.c2_error.AutoSize = true;
            this.c2_error.ForeColor = System.Drawing.Color.White;
            this.c2_error.Location = new System.Drawing.Point(3, 157);
            this.c2_error.Name = "c2_error";
            this.c2_error.Size = new System.Drawing.Size(32, 13);
            this.c2_error.TabIndex = 15;
            this.c2_error.Text = "Error:";
            this.c2_error.Click += new System.EventHandler(this.c2_error_Click);
            // 
            // c2_test
            // 
            this.c2_test.Enabled = false;
            this.c2_test.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c2_test.Location = new System.Drawing.Point(464, 112);
            this.c2_test.Name = "c2_test";
            this.c2_test.Size = new System.Drawing.Size(108, 28);
            this.c2_test.TabIndex = 6;
            this.c2_test.Text = "Test";
            this.c2_test.UseVisualStyleBackColor = true;
            this.c2_test.Click += new System.EventHandler(this.c2_test_Click);
            // 
            // c2_delay
            // 
            this.c2_delay.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c2_delay.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c2_delay.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c2_delay.Enabled = false;
            this.c2_delay.Location = new System.Drawing.Point(274, 120);
            this.c2_delay.Name = "c2_delay";
            this.c2_delay.Size = new System.Drawing.Size(69, 20);
            this.c2_delay.TabIndex = 14;
            this.c2_delay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c2_delay.TextChanged += new System.EventHandler(this.c2_delay_TextChanged);
            // 
            // c2_pulse
            // 
            this.c2_pulse.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c2_pulse.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c2_pulse.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c2_pulse.Enabled = false;
            this.c2_pulse.Location = new System.Drawing.Point(274, 75);
            this.c2_pulse.Name = "c2_pulse";
            this.c2_pulse.Size = new System.Drawing.Size(69, 20);
            this.c2_pulse.TabIndex = 13;
            this.c2_pulse.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c2_pulse.TextChanged += new System.EventHandler(this.c2_pulse_TextChanged);
            // 
            // c2_strobe
            // 
            this.c2_strobe.Enabled = false;
            this.c2_strobe.FormattingEnabled = true;
            this.c2_strobe.Items.AddRange(new object[] {
            "None",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.c2_strobe.Location = new System.Drawing.Point(274, 29);
            this.c2_strobe.Name = "c2_strobe";
            this.c2_strobe.Size = new System.Drawing.Size(69, 21);
            this.c2_strobe.TabIndex = 12;
            this.c2_strobe.Text = "None";
            this.c2_strobe.SelectedIndexChanged += new System.EventHandler(this.c2_strobe_SelectedIndexChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(215, 120);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(44, 18);
            this.label22.TabIndex = 11;
            this.label22.Text = "Delay";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(215, 75);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(41, 18);
            this.label23.TabIndex = 10;
            this.label23.Text = "Pulse";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(215, 29);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(48, 18);
            this.label24.TabIndex = 9;
            this.label24.Text = "Strobe";
            // 
            // c2_intensity
            // 
            this.c2_intensity.AutoCompleteCustomSource.AddRange(new string[] {
            "4096"});
            this.c2_intensity.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c2_intensity.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c2_intensity.Location = new System.Drawing.Point(75, 29);
            this.c2_intensity.Name = "c2_intensity";
            this.c2_intensity.Size = new System.Drawing.Size(69, 20);
            this.c2_intensity.TabIndex = 8;
            this.c2_intensity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c2_intensity.TextChanged += new System.EventHandler(this.c2_intensity_TextChanged_1);
            // 
            // c2_edge
            // 
            this.c2_edge.Enabled = false;
            this.c2_edge.FormattingEnabled = true;
            this.c2_edge.Items.AddRange(new object[] {
            "Rising",
            "Falling"});
            this.c2_edge.Location = new System.Drawing.Point(75, 72);
            this.c2_edge.Name = "c2_edge";
            this.c2_edge.Size = new System.Drawing.Size(69, 21);
            this.c2_edge.TabIndex = 7;
            this.c2_edge.Text = "Rising";
            this.c2_edge.SelectedIndexChanged += new System.EventHandler(this.c2_edge_SelectedIndexChanged);
            // 
            // c2_mode
            // 
            this.c2_mode.FormattingEnabled = true;
            this.c2_mode.Items.AddRange(new object[] {
            "Strobe",
            "Static"});
            this.c2_mode.Location = new System.Drawing.Point(75, 120);
            this.c2_mode.Name = "c2_mode";
            this.c2_mode.Size = new System.Drawing.Size(69, 21);
            this.c2_mode.TabIndex = 6;
            this.c2_mode.Text = "Static";
            this.c2_mode.SelectedIndexChanged += new System.EventHandler(this.c2_mode_SelectedIndexChanged);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(3, 120);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(44, 18);
            this.label25.TabIndex = 3;
            this.label25.Text = "Mode";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(3, 75);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(39, 18);
            this.label26.TabIndex = 2;
            this.label26.Text = "Edge";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(3, 29);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(61, 18);
            this.label27.TabIndex = 1;
            this.label27.Text = "Intensity";
            // 
            // c2_title
            // 
            this.c2_title.AutoSize = true;
            this.c2_title.Location = new System.Drawing.Point(3, 3);
            this.c2_title.Name = "c2_title";
            this.c2_title.Size = new System.Drawing.Size(93, 13);
            this.c2_title.TabIndex = 0;
            this.c2_title.Text = "Channel 2 [Green]";
            this.c2_title.Click += new System.EventHandler(this.c2_title_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.c6_panel);
            this.tabPage2.Controls.Add(this.c4_panel);
            this.tabPage2.Controls.Add(this.c5_panel);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(611, 570);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "G2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // c6_panel
            // 
            this.c6_panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c6_panel.Controls.Add(this.c6_status);
            this.c6_panel.Controls.Add(this.c6_error);
            this.c6_panel.Controls.Add(this.c6_test);
            this.c6_panel.Controls.Add(this.c6_delay);
            this.c6_panel.Controls.Add(this.c6_pulse);
            this.c6_panel.Controls.Add(this.c6_strobe);
            this.c6_panel.Controls.Add(this.label14);
            this.c6_panel.Controls.Add(this.label15);
            this.c6_panel.Controls.Add(this.label16);
            this.c6_panel.Controls.Add(this.c6_intensity);
            this.c6_panel.Controls.Add(this.c6_edge);
            this.c6_panel.Controls.Add(this.c6_mode);
            this.c6_panel.Controls.Add(this.label17);
            this.c6_panel.Controls.Add(this.label18);
            this.c6_panel.Controls.Add(this.label19);
            this.c6_panel.Controls.Add(this.c6_title);
            this.c6_panel.Location = new System.Drawing.Point(0, 382);
            this.c6_panel.Name = "c6_panel";
            this.c6_panel.Size = new System.Drawing.Size(607, 182);
            this.c6_panel.TabIndex = 21;
            // 
            // c6_status
            // 
            this.c6_status.BackColor = System.Drawing.Color.Blue;
            this.c6_status.Enabled = false;
            this.c6_status.Location = new System.Drawing.Point(464, 29);
            this.c6_status.Name = "c6_status";
            this.c6_status.Size = new System.Drawing.Size(108, 83);
            this.c6_status.TabIndex = 16;
            this.c6_status.UseVisualStyleBackColor = false;
            // 
            // c6_error
            // 
            this.c6_error.AutoSize = true;
            this.c6_error.ForeColor = System.Drawing.Color.White;
            this.c6_error.Location = new System.Drawing.Point(3, 157);
            this.c6_error.Name = "c6_error";
            this.c6_error.Size = new System.Drawing.Size(32, 13);
            this.c6_error.TabIndex = 15;
            this.c6_error.Text = "Error:";
            // 
            // c6_test
            // 
            this.c6_test.Enabled = false;
            this.c6_test.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c6_test.Location = new System.Drawing.Point(464, 112);
            this.c6_test.Name = "c6_test";
            this.c6_test.Size = new System.Drawing.Size(108, 28);
            this.c6_test.TabIndex = 6;
            this.c6_test.Text = "Test";
            this.c6_test.UseVisualStyleBackColor = true;
            this.c6_test.Click += new System.EventHandler(this.c6_test_Click);
            // 
            // c6_delay
            // 
            this.c6_delay.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c6_delay.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c6_delay.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c6_delay.Enabled = false;
            this.c6_delay.Location = new System.Drawing.Point(274, 120);
            this.c6_delay.Name = "c6_delay";
            this.c6_delay.Size = new System.Drawing.Size(69, 20);
            this.c6_delay.TabIndex = 14;
            this.c6_delay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c6_delay.TextChanged += new System.EventHandler(this.c6_delay_TextChanged);
            // 
            // c6_pulse
            // 
            this.c6_pulse.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c6_pulse.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c6_pulse.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c6_pulse.Enabled = false;
            this.c6_pulse.Location = new System.Drawing.Point(274, 75);
            this.c6_pulse.Name = "c6_pulse";
            this.c6_pulse.Size = new System.Drawing.Size(69, 20);
            this.c6_pulse.TabIndex = 13;
            this.c6_pulse.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c6_pulse.TextChanged += new System.EventHandler(this.c6_pulse_TextChanged);
            // 
            // c6_strobe
            // 
            this.c6_strobe.Enabled = false;
            this.c6_strobe.FormattingEnabled = true;
            this.c6_strobe.Items.AddRange(new object[] {
            "None",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.c6_strobe.Location = new System.Drawing.Point(274, 29);
            this.c6_strobe.Name = "c6_strobe";
            this.c6_strobe.Size = new System.Drawing.Size(69, 21);
            this.c6_strobe.TabIndex = 12;
            this.c6_strobe.Text = "None";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(215, 120);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(44, 18);
            this.label14.TabIndex = 11;
            this.label14.Text = "Delay";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(215, 75);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(41, 18);
            this.label15.TabIndex = 10;
            this.label15.Text = "Pulse";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(215, 29);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(48, 18);
            this.label16.TabIndex = 9;
            this.label16.Text = "Strobe";
            // 
            // c6_intensity
            // 
            this.c6_intensity.AutoCompleteCustomSource.AddRange(new string[] {
            "4096"});
            this.c6_intensity.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c6_intensity.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c6_intensity.Location = new System.Drawing.Point(75, 29);
            this.c6_intensity.Name = "c6_intensity";
            this.c6_intensity.Size = new System.Drawing.Size(69, 20);
            this.c6_intensity.TabIndex = 8;
            this.c6_intensity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c6_intensity.TextChanged += new System.EventHandler(this.c6_intensity_TextChanged);
            // 
            // c6_edge
            // 
            this.c6_edge.Enabled = false;
            this.c6_edge.FormattingEnabled = true;
            this.c6_edge.Items.AddRange(new object[] {
            "Rising",
            "Falling"});
            this.c6_edge.Location = new System.Drawing.Point(75, 72);
            this.c6_edge.Name = "c6_edge";
            this.c6_edge.Size = new System.Drawing.Size(69, 21);
            this.c6_edge.TabIndex = 7;
            this.c6_edge.Text = "Rising";
            // 
            // c6_mode
            // 
            this.c6_mode.FormattingEnabled = true;
            this.c6_mode.Items.AddRange(new object[] {
            "Strobe",
            "Static"});
            this.c6_mode.Location = new System.Drawing.Point(75, 120);
            this.c6_mode.Name = "c6_mode";
            this.c6_mode.Size = new System.Drawing.Size(69, 21);
            this.c6_mode.TabIndex = 6;
            this.c6_mode.Text = "Static";
            this.c6_mode.SelectedIndexChanged += new System.EventHandler(this.c6_mode_SelectedIndexChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(3, 120);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(44, 18);
            this.label17.TabIndex = 3;
            this.label17.Text = "Mode";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(3, 75);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(39, 18);
            this.label18.TabIndex = 2;
            this.label18.Text = "Edge";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(3, 29);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(61, 18);
            this.label19.TabIndex = 1;
            this.label19.Text = "Intensity";
            // 
            // c6_title
            // 
            this.c6_title.AutoSize = true;
            this.c6_title.Location = new System.Drawing.Point(3, 3);
            this.c6_title.Name = "c6_title";
            this.c6_title.Size = new System.Drawing.Size(82, 13);
            this.c6_title.TabIndex = 0;
            this.c6_title.Text = "Channel 6(Blue)";
            // 
            // c4_panel
            // 
            this.c4_panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c4_panel.Controls.Add(this.c4_status);
            this.c4_panel.Controls.Add(this.c4_error);
            this.c4_panel.Controls.Add(this.c4_test);
            this.c4_panel.Controls.Add(this.c4_delay);
            this.c4_panel.Controls.Add(this.c4_pulse);
            this.c4_panel.Controls.Add(this.c4_strobe);
            this.c4_panel.Controls.Add(this.label38);
            this.c4_panel.Controls.Add(this.label39);
            this.c4_panel.Controls.Add(this.label40);
            this.c4_panel.Controls.Add(this.c4_intensity);
            this.c4_panel.Controls.Add(this.c4_edge);
            this.c4_panel.Controls.Add(this.c4_mode);
            this.c4_panel.Controls.Add(this.label41);
            this.c4_panel.Controls.Add(this.label42);
            this.c4_panel.Controls.Add(this.label43);
            this.c4_panel.Controls.Add(this.c4_title);
            this.c4_panel.Location = new System.Drawing.Point(0, 6);
            this.c4_panel.Name = "c4_panel";
            this.c4_panel.Size = new System.Drawing.Size(607, 182);
            this.c4_panel.TabIndex = 19;
            // 
            // c4_status
            // 
            this.c4_status.BackColor = System.Drawing.Color.Red;
            this.c4_status.Enabled = false;
            this.c4_status.Location = new System.Drawing.Point(464, 29);
            this.c4_status.Name = "c4_status";
            this.c4_status.Size = new System.Drawing.Size(108, 83);
            this.c4_status.TabIndex = 16;
            this.c4_status.UseVisualStyleBackColor = false;
            // 
            // c4_error
            // 
            this.c4_error.AutoSize = true;
            this.c4_error.ForeColor = System.Drawing.Color.White;
            this.c4_error.Location = new System.Drawing.Point(3, 157);
            this.c4_error.Name = "c4_error";
            this.c4_error.Size = new System.Drawing.Size(32, 13);
            this.c4_error.TabIndex = 15;
            this.c4_error.Text = "Error:";
            // 
            // c4_test
            // 
            this.c4_test.Enabled = false;
            this.c4_test.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c4_test.Location = new System.Drawing.Point(464, 112);
            this.c4_test.Name = "c4_test";
            this.c4_test.Size = new System.Drawing.Size(108, 28);
            this.c4_test.TabIndex = 6;
            this.c4_test.Text = "Test";
            this.c4_test.UseVisualStyleBackColor = true;
            this.c4_test.Click += new System.EventHandler(this.c4_test_Click);
            // 
            // c4_delay
            // 
            this.c4_delay.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c4_delay.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c4_delay.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c4_delay.Enabled = false;
            this.c4_delay.Location = new System.Drawing.Point(274, 120);
            this.c4_delay.Name = "c4_delay";
            this.c4_delay.Size = new System.Drawing.Size(69, 20);
            this.c4_delay.TabIndex = 14;
            this.c4_delay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c4_delay.TextChanged += new System.EventHandler(this.c4_delay_TextChanged);
            // 
            // c4_pulse
            // 
            this.c4_pulse.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c4_pulse.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c4_pulse.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c4_pulse.Enabled = false;
            this.c4_pulse.Location = new System.Drawing.Point(274, 75);
            this.c4_pulse.Name = "c4_pulse";
            this.c4_pulse.Size = new System.Drawing.Size(69, 20);
            this.c4_pulse.TabIndex = 13;
            this.c4_pulse.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c4_pulse.TextChanged += new System.EventHandler(this.c4_pulse_TextChanged);
            // 
            // c4_strobe
            // 
            this.c4_strobe.Enabled = false;
            this.c4_strobe.FormattingEnabled = true;
            this.c4_strobe.Items.AddRange(new object[] {
            "None",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.c4_strobe.Location = new System.Drawing.Point(274, 29);
            this.c4_strobe.Name = "c4_strobe";
            this.c4_strobe.Size = new System.Drawing.Size(69, 21);
            this.c4_strobe.TabIndex = 12;
            this.c4_strobe.Text = "None";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(215, 120);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(44, 18);
            this.label38.TabIndex = 11;
            this.label38.Text = "Delay";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(215, 75);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(41, 18);
            this.label39.TabIndex = 10;
            this.label39.Text = "Pulse";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(215, 29);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(48, 18);
            this.label40.TabIndex = 9;
            this.label40.Text = "Strobe";
            // 
            // c4_intensity
            // 
            this.c4_intensity.AutoCompleteCustomSource.AddRange(new string[] {
            "4096"});
            this.c4_intensity.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c4_intensity.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c4_intensity.Location = new System.Drawing.Point(75, 29);
            this.c4_intensity.Name = "c4_intensity";
            this.c4_intensity.Size = new System.Drawing.Size(69, 20);
            this.c4_intensity.TabIndex = 8;
            this.c4_intensity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c4_intensity.TextChanged += new System.EventHandler(this.c4_intensity_TextChanged);
            // 
            // c4_edge
            // 
            this.c4_edge.Enabled = false;
            this.c4_edge.FormattingEnabled = true;
            this.c4_edge.Items.AddRange(new object[] {
            "Rising",
            "Falling"});
            this.c4_edge.Location = new System.Drawing.Point(75, 72);
            this.c4_edge.Name = "c4_edge";
            this.c4_edge.Size = new System.Drawing.Size(69, 21);
            this.c4_edge.TabIndex = 7;
            this.c4_edge.Text = "Rising";
            // 
            // c4_mode
            // 
            this.c4_mode.FormattingEnabled = true;
            this.c4_mode.Items.AddRange(new object[] {
            "Strobe",
            "Static"});
            this.c4_mode.Location = new System.Drawing.Point(75, 120);
            this.c4_mode.Name = "c4_mode";
            this.c4_mode.Size = new System.Drawing.Size(69, 21);
            this.c4_mode.TabIndex = 6;
            this.c4_mode.Text = "Static";
            this.c4_mode.SelectedIndexChanged += new System.EventHandler(this.c4_mode_SelectedIndexChanged);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(3, 120);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(44, 18);
            this.label41.TabIndex = 3;
            this.label41.Text = "Mode";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(3, 75);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(39, 18);
            this.label42.TabIndex = 2;
            this.label42.Text = "Edge";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(3, 29);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(61, 18);
            this.label43.TabIndex = 1;
            this.label43.Text = "Intensity";
            // 
            // c4_title
            // 
            this.c4_title.AutoSize = true;
            this.c4_title.Location = new System.Drawing.Point(3, 3);
            this.c4_title.Name = "c4_title";
            this.c4_title.Size = new System.Drawing.Size(81, 13);
            this.c4_title.TabIndex = 0;
            this.c4_title.Text = "Channel 4(Red)";
            // 
            // c5_panel
            // 
            this.c5_panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c5_panel.Controls.Add(this.c5_status);
            this.c5_panel.Controls.Add(this.c5_error);
            this.c5_panel.Controls.Add(this.c5_test);
            this.c5_panel.Controls.Add(this.c5_delay);
            this.c5_panel.Controls.Add(this.c5_pulse);
            this.c5_panel.Controls.Add(this.c5_strobe);
            this.c5_panel.Controls.Add(this.label46);
            this.c5_panel.Controls.Add(this.label47);
            this.c5_panel.Controls.Add(this.label48);
            this.c5_panel.Controls.Add(this.c5_intensity);
            this.c5_panel.Controls.Add(this.c5_edge);
            this.c5_panel.Controls.Add(this.c5_mode);
            this.c5_panel.Controls.Add(this.label49);
            this.c5_panel.Controls.Add(this.label50);
            this.c5_panel.Controls.Add(this.label51);
            this.c5_panel.Controls.Add(this.c5_title);
            this.c5_panel.Location = new System.Drawing.Point(0, 194);
            this.c5_panel.Name = "c5_panel";
            this.c5_panel.Size = new System.Drawing.Size(607, 182);
            this.c5_panel.TabIndex = 20;
            // 
            // c5_status
            // 
            this.c5_status.BackColor = System.Drawing.Color.Lime;
            this.c5_status.Enabled = false;
            this.c5_status.Location = new System.Drawing.Point(464, 29);
            this.c5_status.Name = "c5_status";
            this.c5_status.Size = new System.Drawing.Size(108, 83);
            this.c5_status.TabIndex = 16;
            this.c5_status.UseVisualStyleBackColor = false;
            // 
            // c5_error
            // 
            this.c5_error.AutoSize = true;
            this.c5_error.ForeColor = System.Drawing.Color.White;
            this.c5_error.Location = new System.Drawing.Point(3, 157);
            this.c5_error.Name = "c5_error";
            this.c5_error.Size = new System.Drawing.Size(32, 13);
            this.c5_error.TabIndex = 15;
            this.c5_error.Text = "Error:";
            // 
            // c5_test
            // 
            this.c5_test.Enabled = false;
            this.c5_test.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c5_test.Location = new System.Drawing.Point(464, 112);
            this.c5_test.Name = "c5_test";
            this.c5_test.Size = new System.Drawing.Size(108, 28);
            this.c5_test.TabIndex = 6;
            this.c5_test.Text = "Test";
            this.c5_test.UseVisualStyleBackColor = true;
            this.c5_test.Click += new System.EventHandler(this.c5_test_Click);
            // 
            // c5_delay
            // 
            this.c5_delay.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c5_delay.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c5_delay.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c5_delay.Enabled = false;
            this.c5_delay.Location = new System.Drawing.Point(274, 120);
            this.c5_delay.Name = "c5_delay";
            this.c5_delay.Size = new System.Drawing.Size(69, 20);
            this.c5_delay.TabIndex = 14;
            this.c5_delay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c5_delay.TextChanged += new System.EventHandler(this.c5_delay_TextChanged);
            // 
            // c5_pulse
            // 
            this.c5_pulse.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c5_pulse.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c5_pulse.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c5_pulse.Enabled = false;
            this.c5_pulse.Location = new System.Drawing.Point(274, 75);
            this.c5_pulse.Name = "c5_pulse";
            this.c5_pulse.Size = new System.Drawing.Size(69, 20);
            this.c5_pulse.TabIndex = 13;
            this.c5_pulse.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c5_pulse.TextChanged += new System.EventHandler(this.c5_pulse_TextChanged);
            // 
            // c5_strobe
            // 
            this.c5_strobe.Enabled = false;
            this.c5_strobe.FormattingEnabled = true;
            this.c5_strobe.Items.AddRange(new object[] {
            "None",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.c5_strobe.Location = new System.Drawing.Point(274, 29);
            this.c5_strobe.Name = "c5_strobe";
            this.c5_strobe.Size = new System.Drawing.Size(69, 21);
            this.c5_strobe.TabIndex = 12;
            this.c5_strobe.Text = "None";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(215, 120);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(44, 18);
            this.label46.TabIndex = 11;
            this.label46.Text = "Delay";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(215, 75);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(41, 18);
            this.label47.TabIndex = 10;
            this.label47.Text = "Pulse";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(215, 29);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(48, 18);
            this.label48.TabIndex = 9;
            this.label48.Text = "Strobe";
            // 
            // c5_intensity
            // 
            this.c5_intensity.AutoCompleteCustomSource.AddRange(new string[] {
            "4096"});
            this.c5_intensity.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c5_intensity.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c5_intensity.Location = new System.Drawing.Point(75, 29);
            this.c5_intensity.Name = "c5_intensity";
            this.c5_intensity.Size = new System.Drawing.Size(69, 20);
            this.c5_intensity.TabIndex = 8;
            this.c5_intensity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c5_intensity.TextChanged += new System.EventHandler(this.c5_intensity_TextChanged);
            // 
            // c5_edge
            // 
            this.c5_edge.Enabled = false;
            this.c5_edge.FormattingEnabled = true;
            this.c5_edge.Items.AddRange(new object[] {
            "Rising",
            "Falling"});
            this.c5_edge.Location = new System.Drawing.Point(75, 72);
            this.c5_edge.Name = "c5_edge";
            this.c5_edge.Size = new System.Drawing.Size(69, 21);
            this.c5_edge.TabIndex = 7;
            this.c5_edge.Text = "Rising";
            // 
            // c5_mode
            // 
            this.c5_mode.FormattingEnabled = true;
            this.c5_mode.Items.AddRange(new object[] {
            "Strobe",
            "Static"});
            this.c5_mode.Location = new System.Drawing.Point(75, 120);
            this.c5_mode.Name = "c5_mode";
            this.c5_mode.Size = new System.Drawing.Size(69, 21);
            this.c5_mode.TabIndex = 6;
            this.c5_mode.Text = "Static";
            this.c5_mode.SelectedIndexChanged += new System.EventHandler(this.c5_mode_SelectedIndexChanged);
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(3, 120);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(44, 18);
            this.label49.TabIndex = 3;
            this.label49.Text = "Mode";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(3, 75);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(39, 18);
            this.label50.TabIndex = 2;
            this.label50.Text = "Edge";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(3, 29);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(61, 18);
            this.label51.TabIndex = 1;
            this.label51.Text = "Intensity";
            // 
            // c5_title
            // 
            this.c5_title.AutoSize = true;
            this.c5_title.Location = new System.Drawing.Point(3, 3);
            this.c5_title.Name = "c5_title";
            this.c5_title.Size = new System.Drawing.Size(90, 13);
            this.c5_title.TabIndex = 0;
            this.c5_title.Text = "Channel 5(Green)";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.c9_panel);
            this.tabPage3.Controls.Add(this.c7_panel);
            this.tabPage3.Controls.Add(this.c8_panel);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(611, 570);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "G3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // c9_panel
            // 
            this.c9_panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c9_panel.Controls.Add(this.c9_status);
            this.c9_panel.Controls.Add(this.c9_error);
            this.c9_panel.Controls.Add(this.c9_test);
            this.c9_panel.Controls.Add(this.c9_delay);
            this.c9_panel.Controls.Add(this.c9_pulse);
            this.c9_panel.Controls.Add(this.c9_strobe);
            this.c9_panel.Controls.Add(this.label54);
            this.c9_panel.Controls.Add(this.label55);
            this.c9_panel.Controls.Add(this.label56);
            this.c9_panel.Controls.Add(this.c9_intensity);
            this.c9_panel.Controls.Add(this.c9_edge);
            this.c9_panel.Controls.Add(this.c9_mode);
            this.c9_panel.Controls.Add(this.label57);
            this.c9_panel.Controls.Add(this.label58);
            this.c9_panel.Controls.Add(this.label59);
            this.c9_panel.Controls.Add(this.c9_title);
            this.c9_panel.Location = new System.Drawing.Point(0, 382);
            this.c9_panel.Name = "c9_panel";
            this.c9_panel.Size = new System.Drawing.Size(607, 182);
            this.c9_panel.TabIndex = 21;
            // 
            // c9_status
            // 
            this.c9_status.BackColor = System.Drawing.Color.Blue;
            this.c9_status.Enabled = false;
            this.c9_status.Location = new System.Drawing.Point(464, 29);
            this.c9_status.Name = "c9_status";
            this.c9_status.Size = new System.Drawing.Size(108, 83);
            this.c9_status.TabIndex = 16;
            this.c9_status.UseVisualStyleBackColor = false;
            // 
            // c9_error
            // 
            this.c9_error.AutoSize = true;
            this.c9_error.ForeColor = System.Drawing.Color.White;
            this.c9_error.Location = new System.Drawing.Point(3, 157);
            this.c9_error.Name = "c9_error";
            this.c9_error.Size = new System.Drawing.Size(32, 13);
            this.c9_error.TabIndex = 15;
            this.c9_error.Text = "Error:";
            // 
            // c9_test
            // 
            this.c9_test.Enabled = false;
            this.c9_test.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c9_test.Location = new System.Drawing.Point(464, 112);
            this.c9_test.Name = "c9_test";
            this.c9_test.Size = new System.Drawing.Size(108, 28);
            this.c9_test.TabIndex = 6;
            this.c9_test.Text = "Test";
            this.c9_test.UseVisualStyleBackColor = true;
            this.c9_test.Click += new System.EventHandler(this.c9_test_Click);
            // 
            // c9_delay
            // 
            this.c9_delay.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c9_delay.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c9_delay.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c9_delay.Enabled = false;
            this.c9_delay.Location = new System.Drawing.Point(274, 120);
            this.c9_delay.Name = "c9_delay";
            this.c9_delay.Size = new System.Drawing.Size(69, 20);
            this.c9_delay.TabIndex = 14;
            this.c9_delay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c9_delay.TextChanged += new System.EventHandler(this.c9_delay_TextChanged);
            // 
            // c9_pulse
            // 
            this.c9_pulse.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c9_pulse.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c9_pulse.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c9_pulse.Enabled = false;
            this.c9_pulse.Location = new System.Drawing.Point(274, 75);
            this.c9_pulse.Name = "c9_pulse";
            this.c9_pulse.Size = new System.Drawing.Size(69, 20);
            this.c9_pulse.TabIndex = 13;
            this.c9_pulse.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c9_pulse.TextChanged += new System.EventHandler(this.c9_pulse_TextChanged);
            // 
            // c9_strobe
            // 
            this.c9_strobe.Enabled = false;
            this.c9_strobe.FormattingEnabled = true;
            this.c9_strobe.Items.AddRange(new object[] {
            "None",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.c9_strobe.Location = new System.Drawing.Point(274, 29);
            this.c9_strobe.Name = "c9_strobe";
            this.c9_strobe.Size = new System.Drawing.Size(69, 21);
            this.c9_strobe.TabIndex = 12;
            this.c9_strobe.Text = "None";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(215, 120);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(44, 18);
            this.label54.TabIndex = 11;
            this.label54.Text = "Delay";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(215, 75);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(41, 18);
            this.label55.TabIndex = 10;
            this.label55.Text = "Pulse";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(215, 29);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(48, 18);
            this.label56.TabIndex = 9;
            this.label56.Text = "Strobe";
            // 
            // c9_intensity
            // 
            this.c9_intensity.AutoCompleteCustomSource.AddRange(new string[] {
            "4096"});
            this.c9_intensity.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c9_intensity.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c9_intensity.Location = new System.Drawing.Point(75, 29);
            this.c9_intensity.Name = "c9_intensity";
            this.c9_intensity.Size = new System.Drawing.Size(69, 20);
            this.c9_intensity.TabIndex = 8;
            this.c9_intensity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c9_intensity.TextChanged += new System.EventHandler(this.c9_intensity_TextChanged);
            // 
            // c9_edge
            // 
            this.c9_edge.Enabled = false;
            this.c9_edge.FormattingEnabled = true;
            this.c9_edge.Items.AddRange(new object[] {
            "Rising",
            "Falling"});
            this.c9_edge.Location = new System.Drawing.Point(75, 72);
            this.c9_edge.Name = "c9_edge";
            this.c9_edge.Size = new System.Drawing.Size(69, 21);
            this.c9_edge.TabIndex = 7;
            this.c9_edge.Text = "Rising";
            // 
            // c9_mode
            // 
            this.c9_mode.FormattingEnabled = true;
            this.c9_mode.Items.AddRange(new object[] {
            "Strobe",
            "Static"});
            this.c9_mode.Location = new System.Drawing.Point(75, 120);
            this.c9_mode.Name = "c9_mode";
            this.c9_mode.Size = new System.Drawing.Size(69, 21);
            this.c9_mode.TabIndex = 6;
            this.c9_mode.Text = "Static";
            this.c9_mode.SelectedIndexChanged += new System.EventHandler(this.c9_mode_SelectedIndexChanged);
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.Location = new System.Drawing.Point(3, 120);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(44, 18);
            this.label57.TabIndex = 3;
            this.label57.Text = "Mode";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(3, 75);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(39, 18);
            this.label58.TabIndex = 2;
            this.label58.Text = "Edge";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(3, 29);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(61, 18);
            this.label59.TabIndex = 1;
            this.label59.Text = "Intensity";
            // 
            // c9_title
            // 
            this.c9_title.AutoSize = true;
            this.c9_title.Location = new System.Drawing.Point(3, 3);
            this.c9_title.Name = "c9_title";
            this.c9_title.Size = new System.Drawing.Size(82, 13);
            this.c9_title.TabIndex = 0;
            this.c9_title.Text = "Channel 9(Blue)";
            // 
            // c7_panel
            // 
            this.c7_panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c7_panel.Controls.Add(this.c7_status);
            this.c7_panel.Controls.Add(this.c7_error);
            this.c7_panel.Controls.Add(this.c7_test);
            this.c7_panel.Controls.Add(this.c7_delay);
            this.c7_panel.Controls.Add(this.c7_pulse);
            this.c7_panel.Controls.Add(this.c7_strobe);
            this.c7_panel.Controls.Add(this.label62);
            this.c7_panel.Controls.Add(this.label63);
            this.c7_panel.Controls.Add(this.label64);
            this.c7_panel.Controls.Add(this.c7_intensity);
            this.c7_panel.Controls.Add(this.c7_edge);
            this.c7_panel.Controls.Add(this.c7_mode);
            this.c7_panel.Controls.Add(this.label65);
            this.c7_panel.Controls.Add(this.label66);
            this.c7_panel.Controls.Add(this.label67);
            this.c7_panel.Controls.Add(this.c7_title);
            this.c7_panel.Location = new System.Drawing.Point(0, 6);
            this.c7_panel.Name = "c7_panel";
            this.c7_panel.Size = new System.Drawing.Size(607, 182);
            this.c7_panel.TabIndex = 19;
            // 
            // c7_status
            // 
            this.c7_status.BackColor = System.Drawing.Color.Red;
            this.c7_status.Enabled = false;
            this.c7_status.Location = new System.Drawing.Point(464, 29);
            this.c7_status.Name = "c7_status";
            this.c7_status.Size = new System.Drawing.Size(108, 83);
            this.c7_status.TabIndex = 16;
            this.c7_status.UseVisualStyleBackColor = false;
            // 
            // c7_error
            // 
            this.c7_error.AutoSize = true;
            this.c7_error.ForeColor = System.Drawing.Color.White;
            this.c7_error.Location = new System.Drawing.Point(3, 157);
            this.c7_error.Name = "c7_error";
            this.c7_error.Size = new System.Drawing.Size(32, 13);
            this.c7_error.TabIndex = 15;
            this.c7_error.Text = "Error:";
            // 
            // c7_test
            // 
            this.c7_test.Enabled = false;
            this.c7_test.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c7_test.Location = new System.Drawing.Point(464, 112);
            this.c7_test.Name = "c7_test";
            this.c7_test.Size = new System.Drawing.Size(108, 28);
            this.c7_test.TabIndex = 6;
            this.c7_test.Text = "Test";
            this.c7_test.UseVisualStyleBackColor = true;
            this.c7_test.Click += new System.EventHandler(this.c7_test_Click);
            // 
            // c7_delay
            // 
            this.c7_delay.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c7_delay.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c7_delay.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c7_delay.Enabled = false;
            this.c7_delay.Location = new System.Drawing.Point(274, 120);
            this.c7_delay.Name = "c7_delay";
            this.c7_delay.Size = new System.Drawing.Size(69, 20);
            this.c7_delay.TabIndex = 14;
            this.c7_delay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c7_delay.TextChanged += new System.EventHandler(this.c7_delay_TextChanged);
            // 
            // c7_pulse
            // 
            this.c7_pulse.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c7_pulse.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c7_pulse.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c7_pulse.Enabled = false;
            this.c7_pulse.Location = new System.Drawing.Point(274, 75);
            this.c7_pulse.Name = "c7_pulse";
            this.c7_pulse.Size = new System.Drawing.Size(69, 20);
            this.c7_pulse.TabIndex = 13;
            this.c7_pulse.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c7_pulse.TextChanged += new System.EventHandler(this.c7_pulse_TextChanged);
            // 
            // c7_strobe
            // 
            this.c7_strobe.Enabled = false;
            this.c7_strobe.FormattingEnabled = true;
            this.c7_strobe.Items.AddRange(new object[] {
            "None",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.c7_strobe.Location = new System.Drawing.Point(274, 29);
            this.c7_strobe.Name = "c7_strobe";
            this.c7_strobe.Size = new System.Drawing.Size(69, 21);
            this.c7_strobe.TabIndex = 12;
            this.c7_strobe.Text = "None";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.Location = new System.Drawing.Point(215, 120);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(44, 18);
            this.label62.TabIndex = 11;
            this.label62.Text = "Delay";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.Location = new System.Drawing.Point(215, 75);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(41, 18);
            this.label63.TabIndex = 10;
            this.label63.Text = "Pulse";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(215, 29);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(48, 18);
            this.label64.TabIndex = 9;
            this.label64.Text = "Strobe";
            // 
            // c7_intensity
            // 
            this.c7_intensity.AutoCompleteCustomSource.AddRange(new string[] {
            "4096"});
            this.c7_intensity.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c7_intensity.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c7_intensity.Location = new System.Drawing.Point(75, 29);
            this.c7_intensity.Name = "c7_intensity";
            this.c7_intensity.Size = new System.Drawing.Size(69, 20);
            this.c7_intensity.TabIndex = 8;
            this.c7_intensity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c7_intensity.TextChanged += new System.EventHandler(this.c7_intensity_TextChanged);
            // 
            // c7_edge
            // 
            this.c7_edge.Enabled = false;
            this.c7_edge.FormattingEnabled = true;
            this.c7_edge.Items.AddRange(new object[] {
            "Rising",
            "Falling"});
            this.c7_edge.Location = new System.Drawing.Point(75, 72);
            this.c7_edge.Name = "c7_edge";
            this.c7_edge.Size = new System.Drawing.Size(69, 21);
            this.c7_edge.TabIndex = 7;
            this.c7_edge.Text = "Rising";
            // 
            // c7_mode
            // 
            this.c7_mode.FormattingEnabled = true;
            this.c7_mode.Items.AddRange(new object[] {
            "Strobe",
            "Static"});
            this.c7_mode.Location = new System.Drawing.Point(75, 120);
            this.c7_mode.Name = "c7_mode";
            this.c7_mode.Size = new System.Drawing.Size(69, 21);
            this.c7_mode.TabIndex = 6;
            this.c7_mode.Text = "Static";
            this.c7_mode.SelectedIndexChanged += new System.EventHandler(this.c7_mode_SelectedIndexChanged);
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.Location = new System.Drawing.Point(3, 120);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(44, 18);
            this.label65.TabIndex = 3;
            this.label65.Text = "Mode";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.Location = new System.Drawing.Point(3, 75);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(39, 18);
            this.label66.TabIndex = 2;
            this.label66.Text = "Edge";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(3, 29);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(61, 18);
            this.label67.TabIndex = 1;
            this.label67.Text = "Intensity";
            // 
            // c7_title
            // 
            this.c7_title.AutoSize = true;
            this.c7_title.Location = new System.Drawing.Point(3, 3);
            this.c7_title.Name = "c7_title";
            this.c7_title.Size = new System.Drawing.Size(81, 13);
            this.c7_title.TabIndex = 0;
            this.c7_title.Text = "Channel 7(Red)";
            // 
            // c8_panel
            // 
            this.c8_panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c8_panel.Controls.Add(this.c8_status);
            this.c8_panel.Controls.Add(this.c8_error);
            this.c8_panel.Controls.Add(this.c8_test);
            this.c8_panel.Controls.Add(this.c8_delay);
            this.c8_panel.Controls.Add(this.c8_pulse);
            this.c8_panel.Controls.Add(this.c8_strobe);
            this.c8_panel.Controls.Add(this.label70);
            this.c8_panel.Controls.Add(this.label71);
            this.c8_panel.Controls.Add(this.label72);
            this.c8_panel.Controls.Add(this.c8_intensity);
            this.c8_panel.Controls.Add(this.c8_edge);
            this.c8_panel.Controls.Add(this.c8_mode);
            this.c8_panel.Controls.Add(this.label73);
            this.c8_panel.Controls.Add(this.label74);
            this.c8_panel.Controls.Add(this.label75);
            this.c8_panel.Controls.Add(this.c8_title);
            this.c8_panel.Location = new System.Drawing.Point(0, 194);
            this.c8_panel.Name = "c8_panel";
            this.c8_panel.Size = new System.Drawing.Size(607, 182);
            this.c8_panel.TabIndex = 20;
            // 
            // c8_status
            // 
            this.c8_status.BackColor = System.Drawing.Color.Lime;
            this.c8_status.Enabled = false;
            this.c8_status.Location = new System.Drawing.Point(464, 29);
            this.c8_status.Name = "c8_status";
            this.c8_status.Size = new System.Drawing.Size(108, 83);
            this.c8_status.TabIndex = 16;
            this.c8_status.UseVisualStyleBackColor = false;
            // 
            // c8_error
            // 
            this.c8_error.AutoSize = true;
            this.c8_error.ForeColor = System.Drawing.Color.White;
            this.c8_error.Location = new System.Drawing.Point(3, 157);
            this.c8_error.Name = "c8_error";
            this.c8_error.Size = new System.Drawing.Size(32, 13);
            this.c8_error.TabIndex = 15;
            this.c8_error.Text = "Error:";
            // 
            // c8_test
            // 
            this.c8_test.Enabled = false;
            this.c8_test.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c8_test.Location = new System.Drawing.Point(464, 112);
            this.c8_test.Name = "c8_test";
            this.c8_test.Size = new System.Drawing.Size(108, 28);
            this.c8_test.TabIndex = 6;
            this.c8_test.Text = "Test";
            this.c8_test.UseVisualStyleBackColor = true;
            this.c8_test.Click += new System.EventHandler(this.c8_test_Click);
            // 
            // c8_delay
            // 
            this.c8_delay.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c8_delay.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c8_delay.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c8_delay.Enabled = false;
            this.c8_delay.Location = new System.Drawing.Point(274, 120);
            this.c8_delay.Name = "c8_delay";
            this.c8_delay.Size = new System.Drawing.Size(69, 20);
            this.c8_delay.TabIndex = 14;
            this.c8_delay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c8_delay.TextChanged += new System.EventHandler(this.c8_delay_TextChanged);
            // 
            // c8_pulse
            // 
            this.c8_pulse.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c8_pulse.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c8_pulse.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c8_pulse.Enabled = false;
            this.c8_pulse.Location = new System.Drawing.Point(274, 75);
            this.c8_pulse.Name = "c8_pulse";
            this.c8_pulse.Size = new System.Drawing.Size(69, 20);
            this.c8_pulse.TabIndex = 13;
            this.c8_pulse.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c8_pulse.TextChanged += new System.EventHandler(this.c8_pulse_TextChanged);
            // 
            // c8_strobe
            // 
            this.c8_strobe.Enabled = false;
            this.c8_strobe.FormattingEnabled = true;
            this.c8_strobe.Items.AddRange(new object[] {
            "None",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.c8_strobe.Location = new System.Drawing.Point(274, 29);
            this.c8_strobe.Name = "c8_strobe";
            this.c8_strobe.Size = new System.Drawing.Size(69, 21);
            this.c8_strobe.TabIndex = 12;
            this.c8_strobe.Text = "None";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.Location = new System.Drawing.Point(215, 120);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(44, 18);
            this.label70.TabIndex = 11;
            this.label70.Text = "Delay";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.Location = new System.Drawing.Point(215, 75);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(41, 18);
            this.label71.TabIndex = 10;
            this.label71.Text = "Pulse";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.Location = new System.Drawing.Point(215, 29);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(48, 18);
            this.label72.TabIndex = 9;
            this.label72.Text = "Strobe";
            // 
            // c8_intensity
            // 
            this.c8_intensity.AutoCompleteCustomSource.AddRange(new string[] {
            "4096"});
            this.c8_intensity.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c8_intensity.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c8_intensity.Location = new System.Drawing.Point(75, 29);
            this.c8_intensity.Name = "c8_intensity";
            this.c8_intensity.Size = new System.Drawing.Size(69, 20);
            this.c8_intensity.TabIndex = 8;
            this.c8_intensity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c8_intensity.TextChanged += new System.EventHandler(this.c8_intensity_TextChanged);
            // 
            // c8_edge
            // 
            this.c8_edge.Enabled = false;
            this.c8_edge.FormattingEnabled = true;
            this.c8_edge.Items.AddRange(new object[] {
            "Rising",
            "Falling"});
            this.c8_edge.Location = new System.Drawing.Point(75, 72);
            this.c8_edge.Name = "c8_edge";
            this.c8_edge.Size = new System.Drawing.Size(69, 21);
            this.c8_edge.TabIndex = 7;
            this.c8_edge.Text = "Rising";
            // 
            // c8_mode
            // 
            this.c8_mode.FormattingEnabled = true;
            this.c8_mode.Items.AddRange(new object[] {
            "Strobe",
            "Static"});
            this.c8_mode.Location = new System.Drawing.Point(75, 120);
            this.c8_mode.Name = "c8_mode";
            this.c8_mode.Size = new System.Drawing.Size(69, 21);
            this.c8_mode.TabIndex = 6;
            this.c8_mode.Text = "Static";
            this.c8_mode.SelectedIndexChanged += new System.EventHandler(this.c8_mode_SelectedIndexChanged);
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label73.Location = new System.Drawing.Point(3, 120);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(44, 18);
            this.label73.TabIndex = 3;
            this.label73.Text = "Mode";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.Location = new System.Drawing.Point(3, 75);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(39, 18);
            this.label74.TabIndex = 2;
            this.label74.Text = "Edge";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label75.Location = new System.Drawing.Point(3, 29);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(61, 18);
            this.label75.TabIndex = 1;
            this.label75.Text = "Intensity";
            // 
            // c8_title
            // 
            this.c8_title.AutoSize = true;
            this.c8_title.Location = new System.Drawing.Point(3, 3);
            this.c8_title.Name = "c8_title";
            this.c8_title.Size = new System.Drawing.Size(90, 13);
            this.c8_title.TabIndex = 0;
            this.c8_title.Text = "Channel 8(Green)";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.c12_panel);
            this.tabPage4.Controls.Add(this.c10_panel);
            this.tabPage4.Controls.Add(this.c11_panel);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(611, 570);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "G4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // c12_panel
            // 
            this.c12_panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c12_panel.Controls.Add(this.c12_status);
            this.c12_panel.Controls.Add(this.c12_error);
            this.c12_panel.Controls.Add(this.c12_test);
            this.c12_panel.Controls.Add(this.c12_delay);
            this.c12_panel.Controls.Add(this.c12_pulse);
            this.c12_panel.Controls.Add(this.c12_strobe);
            this.c12_panel.Controls.Add(this.label78);
            this.c12_panel.Controls.Add(this.label79);
            this.c12_panel.Controls.Add(this.label80);
            this.c12_panel.Controls.Add(this.c12_intensity);
            this.c12_panel.Controls.Add(this.c12_edge);
            this.c12_panel.Controls.Add(this.c12_mode);
            this.c12_panel.Controls.Add(this.label81);
            this.c12_panel.Controls.Add(this.label82);
            this.c12_panel.Controls.Add(this.label83);
            this.c12_panel.Controls.Add(this.c12_title);
            this.c12_panel.Location = new System.Drawing.Point(0, 382);
            this.c12_panel.Name = "c12_panel";
            this.c12_panel.Size = new System.Drawing.Size(607, 182);
            this.c12_panel.TabIndex = 21;
            // 
            // c12_status
            // 
            this.c12_status.BackColor = System.Drawing.Color.Blue;
            this.c12_status.Enabled = false;
            this.c12_status.Location = new System.Drawing.Point(464, 29);
            this.c12_status.Name = "c12_status";
            this.c12_status.Size = new System.Drawing.Size(108, 83);
            this.c12_status.TabIndex = 16;
            this.c12_status.UseVisualStyleBackColor = false;
            // 
            // c12_error
            // 
            this.c12_error.AutoSize = true;
            this.c12_error.ForeColor = System.Drawing.Color.White;
            this.c12_error.Location = new System.Drawing.Point(3, 157);
            this.c12_error.Name = "c12_error";
            this.c12_error.Size = new System.Drawing.Size(32, 13);
            this.c12_error.TabIndex = 15;
            this.c12_error.Text = "Error:";
            // 
            // c12_test
            // 
            this.c12_test.Enabled = false;
            this.c12_test.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c12_test.Location = new System.Drawing.Point(464, 112);
            this.c12_test.Name = "c12_test";
            this.c12_test.Size = new System.Drawing.Size(108, 28);
            this.c12_test.TabIndex = 6;
            this.c12_test.Text = "Test";
            this.c12_test.UseVisualStyleBackColor = true;
            this.c12_test.Click += new System.EventHandler(this.c12_test_Click);
            // 
            // c12_delay
            // 
            this.c12_delay.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c12_delay.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c12_delay.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c12_delay.Enabled = false;
            this.c12_delay.Location = new System.Drawing.Point(274, 120);
            this.c12_delay.Name = "c12_delay";
            this.c12_delay.Size = new System.Drawing.Size(69, 20);
            this.c12_delay.TabIndex = 14;
            this.c12_delay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c12_delay.TextChanged += new System.EventHandler(this.c12_delay_TextChanged);
            // 
            // c12_pulse
            // 
            this.c12_pulse.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c12_pulse.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c12_pulse.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c12_pulse.Enabled = false;
            this.c12_pulse.Location = new System.Drawing.Point(274, 75);
            this.c12_pulse.Name = "c12_pulse";
            this.c12_pulse.Size = new System.Drawing.Size(69, 20);
            this.c12_pulse.TabIndex = 13;
            this.c12_pulse.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c12_pulse.TextChanged += new System.EventHandler(this.c12_pulse_TextChanged);
            // 
            // c12_strobe
            // 
            this.c12_strobe.Enabled = false;
            this.c12_strobe.FormattingEnabled = true;
            this.c12_strobe.Items.AddRange(new object[] {
            "None",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.c12_strobe.Location = new System.Drawing.Point(274, 29);
            this.c12_strobe.Name = "c12_strobe";
            this.c12_strobe.Size = new System.Drawing.Size(69, 21);
            this.c12_strobe.TabIndex = 12;
            this.c12_strobe.Text = "None";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label78.Location = new System.Drawing.Point(215, 120);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(44, 18);
            this.label78.TabIndex = 11;
            this.label78.Text = "Delay";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label79.Location = new System.Drawing.Point(215, 75);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(41, 18);
            this.label79.TabIndex = 10;
            this.label79.Text = "Pulse";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label80.Location = new System.Drawing.Point(215, 29);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(48, 18);
            this.label80.TabIndex = 9;
            this.label80.Text = "Strobe";
            // 
            // c12_intensity
            // 
            this.c12_intensity.AutoCompleteCustomSource.AddRange(new string[] {
            "4096"});
            this.c12_intensity.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c12_intensity.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c12_intensity.Location = new System.Drawing.Point(75, 29);
            this.c12_intensity.Name = "c12_intensity";
            this.c12_intensity.Size = new System.Drawing.Size(69, 20);
            this.c12_intensity.TabIndex = 8;
            this.c12_intensity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c12_intensity.TextChanged += new System.EventHandler(this.c12_intensity_TextChanged);
            // 
            // c12_edge
            // 
            this.c12_edge.Enabled = false;
            this.c12_edge.FormattingEnabled = true;
            this.c12_edge.Items.AddRange(new object[] {
            "Rising",
            "Falling"});
            this.c12_edge.Location = new System.Drawing.Point(75, 72);
            this.c12_edge.Name = "c12_edge";
            this.c12_edge.Size = new System.Drawing.Size(69, 21);
            this.c12_edge.TabIndex = 7;
            this.c12_edge.Text = "Rising";
            // 
            // c12_mode
            // 
            this.c12_mode.FormattingEnabled = true;
            this.c12_mode.Items.AddRange(new object[] {
            "Strobe",
            "Static"});
            this.c12_mode.Location = new System.Drawing.Point(75, 120);
            this.c12_mode.Name = "c12_mode";
            this.c12_mode.Size = new System.Drawing.Size(69, 21);
            this.c12_mode.TabIndex = 6;
            this.c12_mode.Text = "Static";
            this.c12_mode.SelectedIndexChanged += new System.EventHandler(this.c12_mode_SelectedIndexChanged);
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label81.Location = new System.Drawing.Point(3, 120);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(44, 18);
            this.label81.TabIndex = 3;
            this.label81.Text = "Mode";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label82.Location = new System.Drawing.Point(3, 75);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(39, 18);
            this.label82.TabIndex = 2;
            this.label82.Text = "Edge";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label83.Location = new System.Drawing.Point(3, 29);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(61, 18);
            this.label83.TabIndex = 1;
            this.label83.Text = "Intensity";
            // 
            // c12_title
            // 
            this.c12_title.AutoSize = true;
            this.c12_title.Location = new System.Drawing.Point(3, 3);
            this.c12_title.Name = "c12_title";
            this.c12_title.Size = new System.Drawing.Size(88, 13);
            this.c12_title.TabIndex = 0;
            this.c12_title.Text = "Channel 12(Blue)";
            // 
            // c10_panel
            // 
            this.c10_panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c10_panel.Controls.Add(this.c10_status);
            this.c10_panel.Controls.Add(this.c10_error);
            this.c10_panel.Controls.Add(this.c10_test);
            this.c10_panel.Controls.Add(this.c10_delay);
            this.c10_panel.Controls.Add(this.c10_pulse);
            this.c10_panel.Controls.Add(this.c10_strobe);
            this.c10_panel.Controls.Add(this.label86);
            this.c10_panel.Controls.Add(this.label87);
            this.c10_panel.Controls.Add(this.label88);
            this.c10_panel.Controls.Add(this.c10_intensity);
            this.c10_panel.Controls.Add(this.c10_edge);
            this.c10_panel.Controls.Add(this.c10_mode);
            this.c10_panel.Controls.Add(this.label89);
            this.c10_panel.Controls.Add(this.label90);
            this.c10_panel.Controls.Add(this.label91);
            this.c10_panel.Controls.Add(this.c10_title);
            this.c10_panel.Location = new System.Drawing.Point(0, 6);
            this.c10_panel.Name = "c10_panel";
            this.c10_panel.Size = new System.Drawing.Size(607, 182);
            this.c10_panel.TabIndex = 19;
            // 
            // c10_status
            // 
            this.c10_status.BackColor = System.Drawing.Color.Red;
            this.c10_status.Enabled = false;
            this.c10_status.Location = new System.Drawing.Point(464, 29);
            this.c10_status.Name = "c10_status";
            this.c10_status.Size = new System.Drawing.Size(108, 83);
            this.c10_status.TabIndex = 16;
            this.c10_status.UseVisualStyleBackColor = false;
            // 
            // c10_error
            // 
            this.c10_error.AutoSize = true;
            this.c10_error.ForeColor = System.Drawing.Color.White;
            this.c10_error.Location = new System.Drawing.Point(3, 157);
            this.c10_error.Name = "c10_error";
            this.c10_error.Size = new System.Drawing.Size(32, 13);
            this.c10_error.TabIndex = 15;
            this.c10_error.Text = "Error:";
            // 
            // c10_test
            // 
            this.c10_test.Enabled = false;
            this.c10_test.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c10_test.Location = new System.Drawing.Point(464, 112);
            this.c10_test.Name = "c10_test";
            this.c10_test.Size = new System.Drawing.Size(108, 28);
            this.c10_test.TabIndex = 6;
            this.c10_test.Text = "Test";
            this.c10_test.UseVisualStyleBackColor = true;
            this.c10_test.Click += new System.EventHandler(this.c10_test_Click);
            // 
            // c10_delay
            // 
            this.c10_delay.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c10_delay.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c10_delay.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c10_delay.Enabled = false;
            this.c10_delay.Location = new System.Drawing.Point(274, 120);
            this.c10_delay.Name = "c10_delay";
            this.c10_delay.Size = new System.Drawing.Size(69, 20);
            this.c10_delay.TabIndex = 14;
            this.c10_delay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c10_delay.TextChanged += new System.EventHandler(this.c10_delay_TextChanged);
            // 
            // c10_pulse
            // 
            this.c10_pulse.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c10_pulse.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c10_pulse.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c10_pulse.Enabled = false;
            this.c10_pulse.Location = new System.Drawing.Point(274, 75);
            this.c10_pulse.Name = "c10_pulse";
            this.c10_pulse.Size = new System.Drawing.Size(69, 20);
            this.c10_pulse.TabIndex = 13;
            this.c10_pulse.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c10_pulse.TextChanged += new System.EventHandler(this.c10_pulse_TextChanged);
            // 
            // c10_strobe
            // 
            this.c10_strobe.Enabled = false;
            this.c10_strobe.FormattingEnabled = true;
            this.c10_strobe.Items.AddRange(new object[] {
            "None",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.c10_strobe.Location = new System.Drawing.Point(274, 29);
            this.c10_strobe.Name = "c10_strobe";
            this.c10_strobe.Size = new System.Drawing.Size(69, 21);
            this.c10_strobe.TabIndex = 12;
            this.c10_strobe.Text = "None";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label86.Location = new System.Drawing.Point(215, 120);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(44, 18);
            this.label86.TabIndex = 11;
            this.label86.Text = "Delay";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label87.Location = new System.Drawing.Point(215, 75);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(41, 18);
            this.label87.TabIndex = 10;
            this.label87.Text = "Pulse";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label88.Location = new System.Drawing.Point(215, 29);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(48, 18);
            this.label88.TabIndex = 9;
            this.label88.Text = "Strobe";
            // 
            // c10_intensity
            // 
            this.c10_intensity.AutoCompleteCustomSource.AddRange(new string[] {
            "4096"});
            this.c10_intensity.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c10_intensity.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c10_intensity.Location = new System.Drawing.Point(75, 29);
            this.c10_intensity.Name = "c10_intensity";
            this.c10_intensity.Size = new System.Drawing.Size(69, 20);
            this.c10_intensity.TabIndex = 8;
            this.c10_intensity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c10_intensity.TextChanged += new System.EventHandler(this.c10_intensity_TextChanged);
            // 
            // c10_edge
            // 
            this.c10_edge.Enabled = false;
            this.c10_edge.FormattingEnabled = true;
            this.c10_edge.Items.AddRange(new object[] {
            "Rising",
            "Falling"});
            this.c10_edge.Location = new System.Drawing.Point(75, 72);
            this.c10_edge.Name = "c10_edge";
            this.c10_edge.Size = new System.Drawing.Size(69, 21);
            this.c10_edge.TabIndex = 7;
            this.c10_edge.Text = "Rising";
            // 
            // c10_mode
            // 
            this.c10_mode.FormattingEnabled = true;
            this.c10_mode.Items.AddRange(new object[] {
            "Strobe",
            "Static"});
            this.c10_mode.Location = new System.Drawing.Point(75, 120);
            this.c10_mode.Name = "c10_mode";
            this.c10_mode.Size = new System.Drawing.Size(69, 21);
            this.c10_mode.TabIndex = 6;
            this.c10_mode.Text = "Static";
            this.c10_mode.SelectedIndexChanged += new System.EventHandler(this.c10_mode_SelectedIndexChanged);
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label89.Location = new System.Drawing.Point(3, 120);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(44, 18);
            this.label89.TabIndex = 3;
            this.label89.Text = "Mode";
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label90.Location = new System.Drawing.Point(3, 75);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(39, 18);
            this.label90.TabIndex = 2;
            this.label90.Text = "Edge";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label91.Location = new System.Drawing.Point(3, 29);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(61, 18);
            this.label91.TabIndex = 1;
            this.label91.Text = "Intensity";
            // 
            // c10_title
            // 
            this.c10_title.AutoSize = true;
            this.c10_title.Location = new System.Drawing.Point(3, 3);
            this.c10_title.Name = "c10_title";
            this.c10_title.Size = new System.Drawing.Size(87, 13);
            this.c10_title.TabIndex = 0;
            this.c10_title.Text = "Channel 10(Red)";
            // 
            // c11_panel
            // 
            this.c11_panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c11_panel.Controls.Add(this.c11_status);
            this.c11_panel.Controls.Add(this.c11_error);
            this.c11_panel.Controls.Add(this.c11_test);
            this.c11_panel.Controls.Add(this.c11_delay);
            this.c11_panel.Controls.Add(this.c11_pulse);
            this.c11_panel.Controls.Add(this.c11_strobe);
            this.c11_panel.Controls.Add(this.label94);
            this.c11_panel.Controls.Add(this.label95);
            this.c11_panel.Controls.Add(this.label96);
            this.c11_panel.Controls.Add(this.c11_intensity);
            this.c11_panel.Controls.Add(this.c11_edge);
            this.c11_panel.Controls.Add(this.c11_mode);
            this.c11_panel.Controls.Add(this.label97);
            this.c11_panel.Controls.Add(this.label98);
            this.c11_panel.Controls.Add(this.label99);
            this.c11_panel.Controls.Add(this.c11_title);
            this.c11_panel.Location = new System.Drawing.Point(0, 194);
            this.c11_panel.Name = "c11_panel";
            this.c11_panel.Size = new System.Drawing.Size(607, 182);
            this.c11_panel.TabIndex = 20;
            // 
            // c11_status
            // 
            this.c11_status.BackColor = System.Drawing.Color.Lime;
            this.c11_status.Enabled = false;
            this.c11_status.Location = new System.Drawing.Point(464, 29);
            this.c11_status.Name = "c11_status";
            this.c11_status.Size = new System.Drawing.Size(108, 83);
            this.c11_status.TabIndex = 16;
            this.c11_status.UseVisualStyleBackColor = false;
            // 
            // c11_error
            // 
            this.c11_error.AutoSize = true;
            this.c11_error.ForeColor = System.Drawing.Color.White;
            this.c11_error.Location = new System.Drawing.Point(3, 157);
            this.c11_error.Name = "c11_error";
            this.c11_error.Size = new System.Drawing.Size(32, 13);
            this.c11_error.TabIndex = 15;
            this.c11_error.Text = "Error:";
            // 
            // c11_test
            // 
            this.c11_test.Enabled = false;
            this.c11_test.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c11_test.Location = new System.Drawing.Point(464, 112);
            this.c11_test.Name = "c11_test";
            this.c11_test.Size = new System.Drawing.Size(108, 28);
            this.c11_test.TabIndex = 6;
            this.c11_test.Text = "Test";
            this.c11_test.UseVisualStyleBackColor = true;
            this.c11_test.Click += new System.EventHandler(this.c11_test_Click);
            // 
            // c11_delay
            // 
            this.c11_delay.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c11_delay.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c11_delay.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c11_delay.Enabled = false;
            this.c11_delay.Location = new System.Drawing.Point(274, 120);
            this.c11_delay.Name = "c11_delay";
            this.c11_delay.Size = new System.Drawing.Size(69, 20);
            this.c11_delay.TabIndex = 14;
            this.c11_delay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c11_delay.TextChanged += new System.EventHandler(this.c11_delay_TextChanged);
            // 
            // c11_pulse
            // 
            this.c11_pulse.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c11_pulse.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c11_pulse.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c11_pulse.Enabled = false;
            this.c11_pulse.Location = new System.Drawing.Point(274, 75);
            this.c11_pulse.Name = "c11_pulse";
            this.c11_pulse.Size = new System.Drawing.Size(69, 20);
            this.c11_pulse.TabIndex = 13;
            this.c11_pulse.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c11_pulse.TextChanged += new System.EventHandler(this.c11_pulse_TextChanged);
            // 
            // c11_strobe
            // 
            this.c11_strobe.Enabled = false;
            this.c11_strobe.FormattingEnabled = true;
            this.c11_strobe.Items.AddRange(new object[] {
            "None",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.c11_strobe.Location = new System.Drawing.Point(274, 29);
            this.c11_strobe.Name = "c11_strobe";
            this.c11_strobe.Size = new System.Drawing.Size(69, 21);
            this.c11_strobe.TabIndex = 12;
            this.c11_strobe.Text = "None";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label94.Location = new System.Drawing.Point(215, 120);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(44, 18);
            this.label94.TabIndex = 11;
            this.label94.Text = "Delay";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label95.Location = new System.Drawing.Point(215, 75);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(41, 18);
            this.label95.TabIndex = 10;
            this.label95.Text = "Pulse";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label96.Location = new System.Drawing.Point(215, 29);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(48, 18);
            this.label96.TabIndex = 9;
            this.label96.Text = "Strobe";
            // 
            // c11_intensity
            // 
            this.c11_intensity.AutoCompleteCustomSource.AddRange(new string[] {
            "4096"});
            this.c11_intensity.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c11_intensity.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c11_intensity.Location = new System.Drawing.Point(75, 29);
            this.c11_intensity.Name = "c11_intensity";
            this.c11_intensity.Size = new System.Drawing.Size(69, 20);
            this.c11_intensity.TabIndex = 8;
            this.c11_intensity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c11_intensity.TextChanged += new System.EventHandler(this.c11_intensity_TextChanged);
            // 
            // c11_edge
            // 
            this.c11_edge.Enabled = false;
            this.c11_edge.FormattingEnabled = true;
            this.c11_edge.Items.AddRange(new object[] {
            "Rising",
            "Falling"});
            this.c11_edge.Location = new System.Drawing.Point(75, 72);
            this.c11_edge.Name = "c11_edge";
            this.c11_edge.Size = new System.Drawing.Size(69, 21);
            this.c11_edge.TabIndex = 7;
            this.c11_edge.Text = "Rising";
            // 
            // c11_mode
            // 
            this.c11_mode.FormattingEnabled = true;
            this.c11_mode.Items.AddRange(new object[] {
            "Strobe",
            "Static"});
            this.c11_mode.Location = new System.Drawing.Point(75, 120);
            this.c11_mode.Name = "c11_mode";
            this.c11_mode.Size = new System.Drawing.Size(69, 21);
            this.c11_mode.TabIndex = 6;
            this.c11_mode.Text = "Static";
            this.c11_mode.SelectedIndexChanged += new System.EventHandler(this.c11_mode_SelectedIndexChanged);
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label97.Location = new System.Drawing.Point(3, 120);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(44, 18);
            this.label97.TabIndex = 3;
            this.label97.Text = "Mode";
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label98.Location = new System.Drawing.Point(3, 75);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(39, 18);
            this.label98.TabIndex = 2;
            this.label98.Text = "Edge";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label99.Location = new System.Drawing.Point(3, 29);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(61, 18);
            this.label99.TabIndex = 1;
            this.label99.Text = "Intensity";
            // 
            // c11_title
            // 
            this.c11_title.AutoSize = true;
            this.c11_title.Location = new System.Drawing.Point(3, 3);
            this.c11_title.Name = "c11_title";
            this.c11_title.Size = new System.Drawing.Size(96, 13);
            this.c11_title.TabIndex = 0;
            this.c11_title.Text = "Channel 11(Green)";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.c15_panel);
            this.tabPage5.Controls.Add(this.c13_panel);
            this.tabPage5.Controls.Add(this.c14_panel);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(611, 570);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "G5";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // c15_panel
            // 
            this.c15_panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c15_panel.Controls.Add(this.c15_status);
            this.c15_panel.Controls.Add(this.c15_error);
            this.c15_panel.Controls.Add(this.c15_test);
            this.c15_panel.Controls.Add(this.c15_delay);
            this.c15_panel.Controls.Add(this.c15_pulse);
            this.c15_panel.Controls.Add(this.c15_strobe);
            this.c15_panel.Controls.Add(this.label102);
            this.c15_panel.Controls.Add(this.label103);
            this.c15_panel.Controls.Add(this.label104);
            this.c15_panel.Controls.Add(this.c15_intensity);
            this.c15_panel.Controls.Add(this.c15_edge);
            this.c15_panel.Controls.Add(this.c15_mode);
            this.c15_panel.Controls.Add(this.label105);
            this.c15_panel.Controls.Add(this.label106);
            this.c15_panel.Controls.Add(this.label107);
            this.c15_panel.Controls.Add(this.c15_title);
            this.c15_panel.Location = new System.Drawing.Point(0, 382);
            this.c15_panel.Name = "c15_panel";
            this.c15_panel.Size = new System.Drawing.Size(607, 182);
            this.c15_panel.TabIndex = 21;
            // 
            // c15_status
            // 
            this.c15_status.BackColor = System.Drawing.Color.Blue;
            this.c15_status.Enabled = false;
            this.c15_status.Location = new System.Drawing.Point(464, 29);
            this.c15_status.Name = "c15_status";
            this.c15_status.Size = new System.Drawing.Size(108, 83);
            this.c15_status.TabIndex = 16;
            this.c15_status.UseVisualStyleBackColor = false;
            // 
            // c15_error
            // 
            this.c15_error.AutoSize = true;
            this.c15_error.ForeColor = System.Drawing.Color.White;
            this.c15_error.Location = new System.Drawing.Point(3, 157);
            this.c15_error.Name = "c15_error";
            this.c15_error.Size = new System.Drawing.Size(32, 13);
            this.c15_error.TabIndex = 15;
            this.c15_error.Text = "Error:";
            // 
            // c15_test
            // 
            this.c15_test.Enabled = false;
            this.c15_test.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c15_test.Location = new System.Drawing.Point(464, 112);
            this.c15_test.Name = "c15_test";
            this.c15_test.Size = new System.Drawing.Size(108, 28);
            this.c15_test.TabIndex = 6;
            this.c15_test.Text = "Test";
            this.c15_test.UseVisualStyleBackColor = true;
            this.c15_test.Click += new System.EventHandler(this.c15_test_Click);
            // 
            // c15_delay
            // 
            this.c15_delay.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c15_delay.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c15_delay.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c15_delay.Enabled = false;
            this.c15_delay.Location = new System.Drawing.Point(274, 120);
            this.c15_delay.Name = "c15_delay";
            this.c15_delay.Size = new System.Drawing.Size(69, 20);
            this.c15_delay.TabIndex = 14;
            this.c15_delay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c15_delay.TextChanged += new System.EventHandler(this.c15_delay_TextChanged);
            // 
            // c15_pulse
            // 
            this.c15_pulse.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c15_pulse.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c15_pulse.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c15_pulse.Enabled = false;
            this.c15_pulse.Location = new System.Drawing.Point(274, 75);
            this.c15_pulse.Name = "c15_pulse";
            this.c15_pulse.Size = new System.Drawing.Size(69, 20);
            this.c15_pulse.TabIndex = 13;
            this.c15_pulse.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c15_pulse.TextChanged += new System.EventHandler(this.c15_pulse_TextChanged);
            // 
            // c15_strobe
            // 
            this.c15_strobe.Enabled = false;
            this.c15_strobe.FormattingEnabled = true;
            this.c15_strobe.Items.AddRange(new object[] {
            "None",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.c15_strobe.Location = new System.Drawing.Point(274, 29);
            this.c15_strobe.Name = "c15_strobe";
            this.c15_strobe.Size = new System.Drawing.Size(69, 21);
            this.c15_strobe.TabIndex = 12;
            this.c15_strobe.Text = "None";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label102.Location = new System.Drawing.Point(215, 120);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(44, 18);
            this.label102.TabIndex = 11;
            this.label102.Text = "Delay";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label103.Location = new System.Drawing.Point(215, 75);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(41, 18);
            this.label103.TabIndex = 10;
            this.label103.Text = "Pulse";
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label104.Location = new System.Drawing.Point(215, 29);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(48, 18);
            this.label104.TabIndex = 9;
            this.label104.Text = "Strobe";
            // 
            // c15_intensity
            // 
            this.c15_intensity.AutoCompleteCustomSource.AddRange(new string[] {
            "4096"});
            this.c15_intensity.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c15_intensity.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c15_intensity.Location = new System.Drawing.Point(75, 29);
            this.c15_intensity.Name = "c15_intensity";
            this.c15_intensity.Size = new System.Drawing.Size(69, 20);
            this.c15_intensity.TabIndex = 8;
            this.c15_intensity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c15_intensity.TextChanged += new System.EventHandler(this.c15_intensity_TextChanged);
            // 
            // c15_edge
            // 
            this.c15_edge.Enabled = false;
            this.c15_edge.FormattingEnabled = true;
            this.c15_edge.Items.AddRange(new object[] {
            "Rising",
            "Falling"});
            this.c15_edge.Location = new System.Drawing.Point(75, 72);
            this.c15_edge.Name = "c15_edge";
            this.c15_edge.Size = new System.Drawing.Size(69, 21);
            this.c15_edge.TabIndex = 7;
            this.c15_edge.Text = "Rising";
            // 
            // c15_mode
            // 
            this.c15_mode.FormattingEnabled = true;
            this.c15_mode.Items.AddRange(new object[] {
            "Strobe",
            "Static"});
            this.c15_mode.Location = new System.Drawing.Point(75, 120);
            this.c15_mode.Name = "c15_mode";
            this.c15_mode.Size = new System.Drawing.Size(69, 21);
            this.c15_mode.TabIndex = 6;
            this.c15_mode.Text = "Static";
            this.c15_mode.SelectedIndexChanged += new System.EventHandler(this.c15_mode_SelectedIndexChanged);
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label105.Location = new System.Drawing.Point(3, 120);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(44, 18);
            this.label105.TabIndex = 3;
            this.label105.Text = "Mode";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label106.Location = new System.Drawing.Point(3, 75);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(39, 18);
            this.label106.TabIndex = 2;
            this.label106.Text = "Edge";
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label107.Location = new System.Drawing.Point(3, 29);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(61, 18);
            this.label107.TabIndex = 1;
            this.label107.Text = "Intensity";
            // 
            // c15_title
            // 
            this.c15_title.AutoSize = true;
            this.c15_title.Location = new System.Drawing.Point(3, 3);
            this.c15_title.Name = "c15_title";
            this.c15_title.Size = new System.Drawing.Size(88, 13);
            this.c15_title.TabIndex = 0;
            this.c15_title.Text = "Channel 15(Blue)";
            // 
            // c13_panel
            // 
            this.c13_panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c13_panel.Controls.Add(this.c13_status);
            this.c13_panel.Controls.Add(this.c13_error);
            this.c13_panel.Controls.Add(this.c13_test);
            this.c13_panel.Controls.Add(this.c13_delay);
            this.c13_panel.Controls.Add(this.c13_pulse);
            this.c13_panel.Controls.Add(this.c13_strobe);
            this.c13_panel.Controls.Add(this.label110);
            this.c13_panel.Controls.Add(this.label111);
            this.c13_panel.Controls.Add(this.label112);
            this.c13_panel.Controls.Add(this.c13_intensity);
            this.c13_panel.Controls.Add(this.c13_edge);
            this.c13_panel.Controls.Add(this.c13_mode);
            this.c13_panel.Controls.Add(this.label113);
            this.c13_panel.Controls.Add(this.label114);
            this.c13_panel.Controls.Add(this.label115);
            this.c13_panel.Controls.Add(this.c13_title);
            this.c13_panel.Location = new System.Drawing.Point(0, 6);
            this.c13_panel.Name = "c13_panel";
            this.c13_panel.Size = new System.Drawing.Size(607, 182);
            this.c13_panel.TabIndex = 19;
            // 
            // c13_status
            // 
            this.c13_status.BackColor = System.Drawing.Color.Red;
            this.c13_status.Enabled = false;
            this.c13_status.Location = new System.Drawing.Point(464, 29);
            this.c13_status.Name = "c13_status";
            this.c13_status.Size = new System.Drawing.Size(108, 83);
            this.c13_status.TabIndex = 16;
            this.c13_status.UseVisualStyleBackColor = false;
            // 
            // c13_error
            // 
            this.c13_error.AutoSize = true;
            this.c13_error.ForeColor = System.Drawing.Color.White;
            this.c13_error.Location = new System.Drawing.Point(3, 157);
            this.c13_error.Name = "c13_error";
            this.c13_error.Size = new System.Drawing.Size(32, 13);
            this.c13_error.TabIndex = 15;
            this.c13_error.Text = "Error:";
            // 
            // c13_test
            // 
            this.c13_test.Enabled = false;
            this.c13_test.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c13_test.Location = new System.Drawing.Point(464, 112);
            this.c13_test.Name = "c13_test";
            this.c13_test.Size = new System.Drawing.Size(108, 28);
            this.c13_test.TabIndex = 6;
            this.c13_test.Text = "Test";
            this.c13_test.UseVisualStyleBackColor = true;
            this.c13_test.Click += new System.EventHandler(this.c13_test_Click);
            // 
            // c13_delay
            // 
            this.c13_delay.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c13_delay.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c13_delay.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c13_delay.Enabled = false;
            this.c13_delay.Location = new System.Drawing.Point(274, 120);
            this.c13_delay.Name = "c13_delay";
            this.c13_delay.Size = new System.Drawing.Size(69, 20);
            this.c13_delay.TabIndex = 14;
            this.c13_delay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c13_delay.TextChanged += new System.EventHandler(this.c13_delay_TextChanged);
            // 
            // c13_pulse
            // 
            this.c13_pulse.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c13_pulse.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c13_pulse.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c13_pulse.Enabled = false;
            this.c13_pulse.Location = new System.Drawing.Point(274, 75);
            this.c13_pulse.Name = "c13_pulse";
            this.c13_pulse.Size = new System.Drawing.Size(69, 20);
            this.c13_pulse.TabIndex = 13;
            this.c13_pulse.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c13_pulse.TextChanged += new System.EventHandler(this.c13_pulse_TextChanged);
            // 
            // c13_strobe
            // 
            this.c13_strobe.Enabled = false;
            this.c13_strobe.FormattingEnabled = true;
            this.c13_strobe.Items.AddRange(new object[] {
            "None",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.c13_strobe.Location = new System.Drawing.Point(274, 29);
            this.c13_strobe.Name = "c13_strobe";
            this.c13_strobe.Size = new System.Drawing.Size(69, 21);
            this.c13_strobe.TabIndex = 12;
            this.c13_strobe.Text = "None";
            this.c13_strobe.SelectedIndexChanged += new System.EventHandler(this.c13_strobe_SelectedIndexChanged);
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label110.Location = new System.Drawing.Point(215, 120);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(44, 18);
            this.label110.TabIndex = 11;
            this.label110.Text = "Delay";
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label111.Location = new System.Drawing.Point(215, 75);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(41, 18);
            this.label111.TabIndex = 10;
            this.label111.Text = "Pulse";
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label112.Location = new System.Drawing.Point(215, 29);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(48, 18);
            this.label112.TabIndex = 9;
            this.label112.Text = "Strobe";
            // 
            // c13_intensity
            // 
            this.c13_intensity.AutoCompleteCustomSource.AddRange(new string[] {
            "4096"});
            this.c13_intensity.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c13_intensity.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c13_intensity.Location = new System.Drawing.Point(75, 29);
            this.c13_intensity.Name = "c13_intensity";
            this.c13_intensity.Size = new System.Drawing.Size(69, 20);
            this.c13_intensity.TabIndex = 8;
            this.c13_intensity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c13_intensity.TextChanged += new System.EventHandler(this.c13_intensity_TextChanged);
            // 
            // c13_edge
            // 
            this.c13_edge.Enabled = false;
            this.c13_edge.FormattingEnabled = true;
            this.c13_edge.Items.AddRange(new object[] {
            "Rising",
            "Falling"});
            this.c13_edge.Location = new System.Drawing.Point(75, 72);
            this.c13_edge.Name = "c13_edge";
            this.c13_edge.Size = new System.Drawing.Size(69, 21);
            this.c13_edge.TabIndex = 7;
            this.c13_edge.Text = "Rising";
            this.c13_edge.SelectedIndexChanged += new System.EventHandler(this.c13_edge_SelectedIndexChanged);
            // 
            // c13_mode
            // 
            this.c13_mode.FormattingEnabled = true;
            this.c13_mode.Items.AddRange(new object[] {
            "Strobe",
            "Static"});
            this.c13_mode.Location = new System.Drawing.Point(75, 120);
            this.c13_mode.Name = "c13_mode";
            this.c13_mode.Size = new System.Drawing.Size(69, 21);
            this.c13_mode.TabIndex = 6;
            this.c13_mode.Text = "Static";
            this.c13_mode.SelectedIndexChanged += new System.EventHandler(this.c13_mode_SelectedIndexChanged);
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label113.Location = new System.Drawing.Point(3, 120);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(44, 18);
            this.label113.TabIndex = 3;
            this.label113.Text = "Mode";
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label114.Location = new System.Drawing.Point(3, 75);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(39, 18);
            this.label114.TabIndex = 2;
            this.label114.Text = "Edge";
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label115.Location = new System.Drawing.Point(3, 29);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(61, 18);
            this.label115.TabIndex = 1;
            this.label115.Text = "Intensity";
            // 
            // c13_title
            // 
            this.c13_title.AutoSize = true;
            this.c13_title.Location = new System.Drawing.Point(3, 3);
            this.c13_title.Name = "c13_title";
            this.c13_title.Size = new System.Drawing.Size(87, 13);
            this.c13_title.TabIndex = 0;
            this.c13_title.Text = "Channel 13(Red)";
            // 
            // c14_panel
            // 
            this.c14_panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.c14_panel.Controls.Add(this.c14_status);
            this.c14_panel.Controls.Add(this.c14_error);
            this.c14_panel.Controls.Add(this.c14_test);
            this.c14_panel.Controls.Add(this.c14_delay);
            this.c14_panel.Controls.Add(this.c14_pulse);
            this.c14_panel.Controls.Add(this.c14_strobe);
            this.c14_panel.Controls.Add(this.label118);
            this.c14_panel.Controls.Add(this.label119);
            this.c14_panel.Controls.Add(this.label120);
            this.c14_panel.Controls.Add(this.c14_intensity);
            this.c14_panel.Controls.Add(this.c14_edge);
            this.c14_panel.Controls.Add(this.c14_mode);
            this.c14_panel.Controls.Add(this.label121);
            this.c14_panel.Controls.Add(this.label122);
            this.c14_panel.Controls.Add(this.label123);
            this.c14_panel.Controls.Add(this.c14_title);
            this.c14_panel.Location = new System.Drawing.Point(0, 194);
            this.c14_panel.Name = "c14_panel";
            this.c14_panel.Size = new System.Drawing.Size(607, 182);
            this.c14_panel.TabIndex = 20;
            // 
            // c14_status
            // 
            this.c14_status.BackColor = System.Drawing.Color.Lime;
            this.c14_status.Enabled = false;
            this.c14_status.Location = new System.Drawing.Point(464, 29);
            this.c14_status.Name = "c14_status";
            this.c14_status.Size = new System.Drawing.Size(108, 83);
            this.c14_status.TabIndex = 16;
            this.c14_status.UseVisualStyleBackColor = false;
            // 
            // c14_error
            // 
            this.c14_error.AutoSize = true;
            this.c14_error.ForeColor = System.Drawing.Color.White;
            this.c14_error.Location = new System.Drawing.Point(3, 157);
            this.c14_error.Name = "c14_error";
            this.c14_error.Size = new System.Drawing.Size(32, 13);
            this.c14_error.TabIndex = 15;
            this.c14_error.Text = "Error:";
            // 
            // c14_test
            // 
            this.c14_test.Enabled = false;
            this.c14_test.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c14_test.Location = new System.Drawing.Point(464, 112);
            this.c14_test.Name = "c14_test";
            this.c14_test.Size = new System.Drawing.Size(108, 28);
            this.c14_test.TabIndex = 6;
            this.c14_test.Text = "Test";
            this.c14_test.UseVisualStyleBackColor = true;
            this.c14_test.Click += new System.EventHandler(this.c14_test_Click);
            // 
            // c14_delay
            // 
            this.c14_delay.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c14_delay.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c14_delay.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c14_delay.Enabled = false;
            this.c14_delay.Location = new System.Drawing.Point(274, 120);
            this.c14_delay.Name = "c14_delay";
            this.c14_delay.Size = new System.Drawing.Size(69, 20);
            this.c14_delay.TabIndex = 14;
            this.c14_delay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c14_delay.TextChanged += new System.EventHandler(this.c14_delay_TextChanged);
            // 
            // c14_pulse
            // 
            this.c14_pulse.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c14_pulse.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c14_pulse.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c14_pulse.Enabled = false;
            this.c14_pulse.Location = new System.Drawing.Point(274, 75);
            this.c14_pulse.Name = "c14_pulse";
            this.c14_pulse.Size = new System.Drawing.Size(69, 20);
            this.c14_pulse.TabIndex = 13;
            this.c14_pulse.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c14_pulse.TextChanged += new System.EventHandler(this.c14_pulse_TextChanged);
            // 
            // c14_strobe
            // 
            this.c14_strobe.Enabled = false;
            this.c14_strobe.FormattingEnabled = true;
            this.c14_strobe.Items.AddRange(new object[] {
            "None",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.c14_strobe.Location = new System.Drawing.Point(274, 29);
            this.c14_strobe.Name = "c14_strobe";
            this.c14_strobe.Size = new System.Drawing.Size(69, 21);
            this.c14_strobe.TabIndex = 12;
            this.c14_strobe.Text = "None";
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label118.Location = new System.Drawing.Point(215, 120);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(44, 18);
            this.label118.TabIndex = 11;
            this.label118.Text = "Delay";
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label119.Location = new System.Drawing.Point(215, 75);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(41, 18);
            this.label119.TabIndex = 10;
            this.label119.Text = "Pulse";
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label120.Location = new System.Drawing.Point(215, 29);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(48, 18);
            this.label120.TabIndex = 9;
            this.label120.Text = "Strobe";
            // 
            // c14_intensity
            // 
            this.c14_intensity.AutoCompleteCustomSource.AddRange(new string[] {
            "4096"});
            this.c14_intensity.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c14_intensity.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c14_intensity.Location = new System.Drawing.Point(75, 29);
            this.c14_intensity.Name = "c14_intensity";
            this.c14_intensity.Size = new System.Drawing.Size(69, 20);
            this.c14_intensity.TabIndex = 8;
            this.c14_intensity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c14_intensity.TextChanged += new System.EventHandler(this.c14_intensity_TextChanged);
            // 
            // c14_edge
            // 
            this.c14_edge.Enabled = false;
            this.c14_edge.FormattingEnabled = true;
            this.c14_edge.Items.AddRange(new object[] {
            "Rising",
            "Falling"});
            this.c14_edge.Location = new System.Drawing.Point(75, 72);
            this.c14_edge.Name = "c14_edge";
            this.c14_edge.Size = new System.Drawing.Size(69, 21);
            this.c14_edge.TabIndex = 7;
            this.c14_edge.Text = "Rising";
            // 
            // c14_mode
            // 
            this.c14_mode.FormattingEnabled = true;
            this.c14_mode.Items.AddRange(new object[] {
            "Strobe",
            "Static"});
            this.c14_mode.Location = new System.Drawing.Point(75, 120);
            this.c14_mode.Name = "c14_mode";
            this.c14_mode.Size = new System.Drawing.Size(69, 21);
            this.c14_mode.TabIndex = 6;
            this.c14_mode.Text = "Static";
            this.c14_mode.SelectedIndexChanged += new System.EventHandler(this.c14_mode_SelectedIndexChanged);
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label121.Location = new System.Drawing.Point(3, 120);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(44, 18);
            this.label121.TabIndex = 3;
            this.label121.Text = "Mode";
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label122.Location = new System.Drawing.Point(3, 75);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(39, 18);
            this.label122.TabIndex = 2;
            this.label122.Text = "Edge";
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label123.Location = new System.Drawing.Point(3, 29);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(61, 18);
            this.label123.TabIndex = 1;
            this.label123.Text = "Intensity";
            // 
            // c14_title
            // 
            this.c14_title.AutoSize = true;
            this.c14_title.Location = new System.Drawing.Point(3, 3);
            this.c14_title.Name = "c14_title";
            this.c14_title.Size = new System.Drawing.Size(96, 13);
            this.c14_title.TabIndex = 0;
            this.c14_title.Text = "Channel 14(Green)";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.panel6);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(611, 570);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "G6";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.c16_error);
            this.panel6.Controls.Add(this.c16_status);
            this.panel6.Controls.Add(this.label126);
            this.panel6.Controls.Add(this.c16_test);
            this.panel6.Controls.Add(this.c16_delay);
            this.panel6.Controls.Add(this.c16_pulse);
            this.panel6.Controls.Add(this.c16_strobe);
            this.panel6.Controls.Add(this.label127);
            this.panel6.Controls.Add(this.label128);
            this.panel6.Controls.Add(this.label129);
            this.panel6.Controls.Add(this.c16_intensity);
            this.panel6.Controls.Add(this.c16_edge);
            this.panel6.Controls.Add(this.c16_mode);
            this.panel6.Controls.Add(this.label130);
            this.panel6.Controls.Add(this.label131);
            this.panel6.Controls.Add(this.label132);
            this.panel6.Controls.Add(this.label133);
            this.panel6.Location = new System.Drawing.Point(0, 6);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(607, 182);
            this.panel6.TabIndex = 22;
            // 
            // c16_error
            // 
            this.c16_error.AutoSize = true;
            this.c16_error.ForeColor = System.Drawing.Color.White;
            this.c16_error.Location = new System.Drawing.Point(6, 157);
            this.c16_error.Name = "c16_error";
            this.c16_error.Size = new System.Drawing.Size(427, 13);
            this.c16_error.TabIndex = 17;
            this.c16_error.Text = "Error: Invalid/Missing value inputted for pulse/delay. Please use integers from 0" +
    " to 65,536";
            // 
            // c16_status
            // 
            this.c16_status.BackColor = System.Drawing.Color.Red;
            this.c16_status.Enabled = false;
            this.c16_status.Location = new System.Drawing.Point(464, 29);
            this.c16_status.Name = "c16_status";
            this.c16_status.Size = new System.Drawing.Size(108, 83);
            this.c16_status.TabIndex = 16;
            this.c16_status.UseVisualStyleBackColor = false;
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.ForeColor = System.Drawing.Color.White;
            this.label126.Location = new System.Drawing.Point(3, 157);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(32, 13);
            this.label126.TabIndex = 15;
            this.label126.Text = "Error:";
            // 
            // c16_test
            // 
            this.c16_test.Enabled = false;
            this.c16_test.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c16_test.Location = new System.Drawing.Point(464, 112);
            this.c16_test.Name = "c16_test";
            this.c16_test.Size = new System.Drawing.Size(108, 28);
            this.c16_test.TabIndex = 6;
            this.c16_test.Text = "Test";
            this.c16_test.UseVisualStyleBackColor = true;
            this.c16_test.Click += new System.EventHandler(this.button8_Click);
            // 
            // c16_delay
            // 
            this.c16_delay.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c16_delay.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c16_delay.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c16_delay.Enabled = false;
            this.c16_delay.Location = new System.Drawing.Point(274, 120);
            this.c16_delay.Name = "c16_delay";
            this.c16_delay.Size = new System.Drawing.Size(69, 20);
            this.c16_delay.TabIndex = 14;
            this.c16_delay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c16_delay.TextChanged += new System.EventHandler(this.c16_delay_TextChanged);
            // 
            // c16_pulse
            // 
            this.c16_pulse.AutoCompleteCustomSource.AddRange(new string[] {
            "1000"});
            this.c16_pulse.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c16_pulse.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c16_pulse.Enabled = false;
            this.c16_pulse.Location = new System.Drawing.Point(274, 75);
            this.c16_pulse.Name = "c16_pulse";
            this.c16_pulse.Size = new System.Drawing.Size(69, 20);
            this.c16_pulse.TabIndex = 13;
            this.c16_pulse.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c16_pulse.TextChanged += new System.EventHandler(this.c16_pulse_TextChanged);
            // 
            // c16_strobe
            // 
            this.c16_strobe.FormattingEnabled = true;
            this.c16_strobe.Items.AddRange(new object[] {
            "None",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.c16_strobe.Location = new System.Drawing.Point(274, 29);
            this.c16_strobe.Name = "c16_strobe";
            this.c16_strobe.Size = new System.Drawing.Size(69, 21);
            this.c16_strobe.TabIndex = 12;
            this.c16_strobe.Text = "None";
            this.c16_strobe.SelectedIndexChanged += new System.EventHandler(this.c16_strobe_SelectedIndexChanged);
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label127.Location = new System.Drawing.Point(215, 120);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(44, 18);
            this.label127.TabIndex = 11;
            this.label127.Text = "Delay";
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label128.Location = new System.Drawing.Point(215, 75);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(41, 18);
            this.label128.TabIndex = 10;
            this.label128.Text = "Pulse";
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label129.Location = new System.Drawing.Point(215, 29);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(48, 18);
            this.label129.TabIndex = 9;
            this.label129.Text = "Strobe";
            // 
            // c16_intensity
            // 
            this.c16_intensity.AutoCompleteCustomSource.AddRange(new string[] {
            "4096"});
            this.c16_intensity.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.c16_intensity.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.c16_intensity.Location = new System.Drawing.Point(75, 29);
            this.c16_intensity.Name = "c16_intensity";
            this.c16_intensity.Size = new System.Drawing.Size(69, 20);
            this.c16_intensity.TabIndex = 8;
            this.c16_intensity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.c16_intensity.TextChanged += new System.EventHandler(this.c16_intensity_TextChanged);
            // 
            // c16_edge
            // 
            this.c16_edge.Enabled = false;
            this.c16_edge.FormattingEnabled = true;
            this.c16_edge.Items.AddRange(new object[] {
            "Rising",
            "Falling"});
            this.c16_edge.Location = new System.Drawing.Point(75, 72);
            this.c16_edge.Name = "c16_edge";
            this.c16_edge.Size = new System.Drawing.Size(69, 21);
            this.c16_edge.TabIndex = 7;
            this.c16_edge.Text = "Rising";
            this.c16_edge.SelectedIndexChanged += new System.EventHandler(this.c16_edge_SelectedIndexChanged);
            // 
            // c16_mode
            // 
            this.c16_mode.FormattingEnabled = true;
            this.c16_mode.Items.AddRange(new object[] {
            "Strobe",
            "Static"});
            this.c16_mode.Location = new System.Drawing.Point(75, 120);
            this.c16_mode.Name = "c16_mode";
            this.c16_mode.Size = new System.Drawing.Size(69, 21);
            this.c16_mode.TabIndex = 6;
            this.c16_mode.Text = "Static";
            this.c16_mode.SelectedIndexChanged += new System.EventHandler(this.c16_mode_SelectedIndexChanged);
            // 
            // label130
            // 
            this.label130.AutoSize = true;
            this.label130.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label130.Location = new System.Drawing.Point(3, 120);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(44, 18);
            this.label130.TabIndex = 3;
            this.label130.Text = "Mode";
            // 
            // label131
            // 
            this.label131.AutoSize = true;
            this.label131.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label131.Location = new System.Drawing.Point(3, 75);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(39, 18);
            this.label131.TabIndex = 2;
            this.label131.Text = "Edge";
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label132.Location = new System.Drawing.Point(3, 29);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(61, 18);
            this.label132.TabIndex = 1;
            this.label132.Text = "Intensity";
            // 
            // label133
            // 
            this.label133.AutoSize = true;
            this.label133.Location = new System.Drawing.Point(3, 3);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(87, 13);
            this.label133.TabIndex = 0;
            this.label133.Text = "Channel 16(Red)";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(215, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(93, 29);
            this.button2.TabIndex = 4;
            this.button2.Text = "Reset All";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(99, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(110, 29);
            this.button1.TabIndex = 3;
            this.button1.Text = "Clear Intensity";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 19);
            this.label3.TabIndex = 2;
            this.label3.Text = "LED Settings";
            // 
            // testUpdatedComms
            // 
            this.testUpdatedComms.Location = new System.Drawing.Point(7, 165);
            this.testUpdatedComms.Name = "testUpdatedComms";
            this.testUpdatedComms.Size = new System.Drawing.Size(144, 29);
            this.testUpdatedComms.TabIndex = 5;
            this.testUpdatedComms.Text = "testUpdatedComms";
            this.testUpdatedComms.UseVisualStyleBackColor = true;
            this.testUpdatedComms.Click += new System.EventHandler(this.testUpdatedComms_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(998, 828);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.g5_panel.ResumeLayout(false);
            this.g5_panel.PerformLayout();
            this.g4_panel.ResumeLayout(false);
            this.g4_panel.PerformLayout();
            this.g3_panel.ResumeLayout(false);
            this.g3_panel.PerformLayout();
            this.g2_panel.ResumeLayout(false);
            this.g2_panel.PerformLayout();
            this.g1_panel.ResumeLayout(false);
            this.g1_panel.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.mainTab.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.c3_panel.ResumeLayout(false);
            this.c3_panel.PerformLayout();
            this.c1_panel.ResumeLayout(false);
            this.c1_panel.PerformLayout();
            this.c2_panel.ResumeLayout(false);
            this.c2_panel.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.c6_panel.ResumeLayout(false);
            this.c6_panel.PerformLayout();
            this.c4_panel.ResumeLayout(false);
            this.c4_panel.PerformLayout();
            this.c5_panel.ResumeLayout(false);
            this.c5_panel.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.c9_panel.ResumeLayout(false);
            this.c9_panel.PerformLayout();
            this.c7_panel.ResumeLayout(false);
            this.c7_panel.PerformLayout();
            this.c8_panel.ResumeLayout(false);
            this.c8_panel.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.c12_panel.ResumeLayout(false);
            this.c12_panel.PerformLayout();
            this.c10_panel.ResumeLayout(false);
            this.c10_panel.PerformLayout();
            this.c11_panel.ResumeLayout(false);
            this.c11_panel.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.c15_panel.ResumeLayout(false);
            this.c15_panel.PerformLayout();
            this.c13_panel.ResumeLayout(false);
            this.c13_panel.PerformLayout();
            this.c14_panel.ResumeLayout(false);
            this.c14_panel.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel c1_panel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label c1_title;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button c1_status;
        private System.Windows.Forms.Label c1_error;
        private System.Windows.Forms.Button c1_test;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel c3_panel;
        private System.Windows.Forms.Button c3_status;
        private System.Windows.Forms.Label c3_error;
        private System.Windows.Forms.Button c3_test;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label c3_title;
        private System.Windows.Forms.Panel c2_panel;
        private System.Windows.Forms.Button c2_status;
        private System.Windows.Forms.Label c2_error;
        private System.Windows.Forms.Button c2_test;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label c2_title;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Panel c6_panel;
        private System.Windows.Forms.Button c6_status;
        private System.Windows.Forms.Label c6_error;
        private System.Windows.Forms.Button c6_test;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label c6_title;
        private System.Windows.Forms.Panel c4_panel;
        private System.Windows.Forms.Button c4_status;
        private System.Windows.Forms.Label c4_error;
        private System.Windows.Forms.Button c4_test;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label c4_title;
        private System.Windows.Forms.Panel c5_panel;
        private System.Windows.Forms.Button c5_status;
        private System.Windows.Forms.Label c5_error;
        private System.Windows.Forms.Button c5_test;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label c5_title;
        private System.Windows.Forms.Panel c9_panel;
        private System.Windows.Forms.Button c9_status;
        private System.Windows.Forms.Label c9_error;
        private System.Windows.Forms.Button c9_test;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label c9_title;
        private System.Windows.Forms.Panel c7_panel;
        private System.Windows.Forms.Button c7_status;
        private System.Windows.Forms.Label c7_error;
        private System.Windows.Forms.Button c7_test;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label c7_title;
        private System.Windows.Forms.Panel c8_panel;
        private System.Windows.Forms.Button c8_status;
        private System.Windows.Forms.Label c8_error;
        private System.Windows.Forms.Button c8_test;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label c8_title;
        private System.Windows.Forms.Panel c12_panel;
        private System.Windows.Forms.Button c12_status;
        private System.Windows.Forms.Label c12_error;
        private System.Windows.Forms.Button c12_test;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label c12_title;
        private System.Windows.Forms.Panel c10_panel;
        private System.Windows.Forms.Button c10_status;
        private System.Windows.Forms.Label c10_error;
        private System.Windows.Forms.Button c10_test;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label c10_title;
        private System.Windows.Forms.Panel c11_panel;
        private System.Windows.Forms.Button c11_status;
        private System.Windows.Forms.Label c11_error;
        private System.Windows.Forms.Button c11_test;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label c11_title;
        private System.Windows.Forms.Panel c15_panel;
        private System.Windows.Forms.Button c15_status;
        private System.Windows.Forms.Label c15_error;
        private System.Windows.Forms.Button c15_test;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label c15_title;
        private System.Windows.Forms.Panel c13_panel;
        private System.Windows.Forms.Button c13_status;
        private System.Windows.Forms.Label c13_error;
        private System.Windows.Forms.Button c13_test;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label c13_title;
        private System.Windows.Forms.Panel c14_panel;
        private System.Windows.Forms.Button c14_status;
        private System.Windows.Forms.Label c14_error;
        private System.Windows.Forms.Button c14_test;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label c14_title;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox lightSelect;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button switchConfig;
        private System.Windows.Forms.Button updateConfig;
        private System.Windows.Forms.Button uploadConfig;
        private System.Windows.Forms.Panel g1_panel;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Panel g2_panel;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Panel g5_panel;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Panel g4_panel;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Panel g3_panel;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Button openConn;
        private System.Windows.Forms.Button closeConn;
        private System.Windows.Forms.ListBox consoleDisplay;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button c16_status;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.Button c16_test;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label109;
        public System.Windows.Forms.ComboBox c1_edge;
        public System.Windows.Forms.ComboBox c1_mode;
        public System.Windows.Forms.TextBox c1_delay;
        public System.Windows.Forms.TextBox c1_pulse;
        public System.Windows.Forms.ComboBox c1_strobe;
        public System.Windows.Forms.TextBox c1_intensity;
        public System.Windows.Forms.TextBox c3_delay;
        public System.Windows.Forms.TextBox c3_pulse;
        public System.Windows.Forms.ComboBox c3_strobe;
        public System.Windows.Forms.TextBox c3_intensity;
        public System.Windows.Forms.ComboBox c3_edge;
        public System.Windows.Forms.ComboBox c3_mode;
        public System.Windows.Forms.TextBox c2_delay;
        public System.Windows.Forms.TextBox c2_pulse;
        public System.Windows.Forms.ComboBox c2_strobe;
        public System.Windows.Forms.TextBox c2_intensity;
        public System.Windows.Forms.ComboBox c2_edge;
        public System.Windows.Forms.ComboBox c2_mode;
        public System.Windows.Forms.ComboBox g1_setting;
        public System.Windows.Forms.ComboBox g2_setting;
        public System.Windows.Forms.ComboBox g5_setting;
        public System.Windows.Forms.ComboBox g4_setting;
        public System.Windows.Forms.ComboBox g3_setting;
        public System.Windows.Forms.TabControl mainTab;
        public System.Windows.Forms.TextBox c6_delay;
        public System.Windows.Forms.TextBox c6_pulse;
        public System.Windows.Forms.ComboBox c6_strobe;
        public System.Windows.Forms.TextBox c6_intensity;
        public System.Windows.Forms.ComboBox c6_edge;
        public System.Windows.Forms.ComboBox c6_mode;
        public System.Windows.Forms.TextBox c4_delay;
        public System.Windows.Forms.TextBox c4_pulse;
        public System.Windows.Forms.ComboBox c4_strobe;
        public System.Windows.Forms.TextBox c4_intensity;
        public System.Windows.Forms.ComboBox c4_edge;
        public System.Windows.Forms.ComboBox c4_mode;
        public System.Windows.Forms.TextBox c5_delay;
        public System.Windows.Forms.TextBox c5_pulse;
        public System.Windows.Forms.ComboBox c5_strobe;
        public System.Windows.Forms.TextBox c5_intensity;
        public System.Windows.Forms.ComboBox c5_edge;
        public System.Windows.Forms.ComboBox c5_mode;
        public System.Windows.Forms.TextBox c9_delay;
        public System.Windows.Forms.TextBox c9_pulse;
        public System.Windows.Forms.ComboBox c9_strobe;
        public System.Windows.Forms.TextBox c9_intensity;
        public System.Windows.Forms.ComboBox c9_edge;
        public System.Windows.Forms.ComboBox c9_mode;
        public System.Windows.Forms.TextBox c7_delay;
        public System.Windows.Forms.TextBox c7_pulse;
        public System.Windows.Forms.ComboBox c7_strobe;
        public System.Windows.Forms.TextBox c7_intensity;
        public System.Windows.Forms.ComboBox c7_edge;
        public System.Windows.Forms.ComboBox c7_mode;
        public System.Windows.Forms.TextBox c8_delay;
        public System.Windows.Forms.TextBox c8_pulse;
        public System.Windows.Forms.ComboBox c8_strobe;
        public System.Windows.Forms.TextBox c8_intensity;
        public System.Windows.Forms.ComboBox c8_edge;
        public System.Windows.Forms.ComboBox c8_mode;
        public System.Windows.Forms.TextBox c12_delay;
        public System.Windows.Forms.TextBox c12_pulse;
        public System.Windows.Forms.ComboBox c12_strobe;
        public System.Windows.Forms.TextBox c12_intensity;
        public System.Windows.Forms.ComboBox c12_edge;
        public System.Windows.Forms.ComboBox c12_mode;
        public System.Windows.Forms.TextBox c10_delay;
        public System.Windows.Forms.TextBox c10_pulse;
        public System.Windows.Forms.ComboBox c10_strobe;
        public System.Windows.Forms.TextBox c10_intensity;
        public System.Windows.Forms.ComboBox c10_edge;
        public System.Windows.Forms.ComboBox c10_mode;
        public System.Windows.Forms.TextBox c11_delay;
        public System.Windows.Forms.TextBox c11_pulse;
        public System.Windows.Forms.ComboBox c11_strobe;
        public System.Windows.Forms.TextBox c11_intensity;
        public System.Windows.Forms.ComboBox c11_edge;
        public System.Windows.Forms.ComboBox c11_mode;
        public System.Windows.Forms.TextBox c15_delay;
        public System.Windows.Forms.TextBox c15_pulse;
        public System.Windows.Forms.ComboBox c15_strobe;
        public System.Windows.Forms.TextBox c15_intensity;
        public System.Windows.Forms.ComboBox c15_edge;
        public System.Windows.Forms.ComboBox c15_mode;
        public System.Windows.Forms.TextBox c13_delay;
        public System.Windows.Forms.TextBox c13_pulse;
        public System.Windows.Forms.ComboBox c13_strobe;
        public System.Windows.Forms.TextBox c13_intensity;
        public System.Windows.Forms.ComboBox c13_edge;
        public System.Windows.Forms.ComboBox c13_mode;
        public System.Windows.Forms.TextBox c14_delay;
        public System.Windows.Forms.TextBox c14_pulse;
        public System.Windows.Forms.ComboBox c14_strobe;
        public System.Windows.Forms.TextBox c14_intensity;
        public System.Windows.Forms.ComboBox c14_edge;
        public System.Windows.Forms.ComboBox c14_mode;
        public System.Windows.Forms.TextBox c16_delay;
        public System.Windows.Forms.TextBox c16_pulse;
        public System.Windows.Forms.ComboBox c16_strobe;
        public System.Windows.Forms.TextBox c16_intensity;
        public System.Windows.Forms.ComboBox c16_edge;
        public System.Windows.Forms.ComboBox c16_mode;
        private System.Windows.Forms.Label c16_error;
        private System.Windows.Forms.Label portError;
        private System.Windows.Forms.TextBox comPort;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Button testUpdatedComms;
    }
}

